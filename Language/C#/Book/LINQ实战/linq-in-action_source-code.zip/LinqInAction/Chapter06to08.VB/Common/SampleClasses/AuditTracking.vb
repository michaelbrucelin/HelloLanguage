﻿Public Class AuditTracking
    Public ID As Integer
    Public TableName As String
    Public UserName As String
    Public AccessDate As DateTime
End Class
