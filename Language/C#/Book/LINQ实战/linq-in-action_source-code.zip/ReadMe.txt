This is the complete source code for the LINQ in Action book.
See http://LinqInAction.net for information.

You can get help in the book's forum:
http://www.manning-sandbox.com/forum.jspa?forumID=302
Please post your feedback there too.