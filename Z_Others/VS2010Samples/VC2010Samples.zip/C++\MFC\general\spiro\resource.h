//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by spiro.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SPIROTYPE                   129
#define IDB_PENCIL                      130
#define IDC_DROPWHEEL                   132
#define IDR_PIECES                      133
#define IDC_DROPRING                    134
#define ID_PENWIDTH                     32773
#define ID_SMALLRING                    32775
#define ID_DRAW                         32776
#define ID_HUGERING                     32776
#define ID_VERYLARGERING                32777
#define ID_MEDIUMRING                   32778
#define ID_ENORMOUSWHEEL                32779
#define ID_HUGEWHEEL                    32780
#define ID_VERYLARGEWHEEL               32781
#define ID_LARGEWHEEL                   32782
#define ID_MEDIUMWHEEL                  32783
#define ID_SMALLWHEEL                   32784
#define ID_TINYWHEEL                    32785
#define ID_REMOVERING                   32795
#define ID_REMOVEWHEEL                  32796
#define ID_DRAWPATTERN                  32797
#define ID_PAUSEDRAWING                 32798
#define ID_TRACEWIDTH                   32799
#define ID_ZOOMIN                       32801
#define ID_ZOOMOUT                      32803
#define ID_BLUE                         32804
#define ID_RED                          32805
#define ID_YELLOW                       32806
#define ID_GREEN                        32807
#define ID_BLACK                        32808
#define ID_PURPLE                       32809
#define IDC_SLOW                        32810
#define ID_FAST                         32811
#define ID_END_DRAWING                  32812
#define ID_TIMERTICK                    32813

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32814
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
