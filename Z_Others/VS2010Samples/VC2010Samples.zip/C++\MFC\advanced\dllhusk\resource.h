//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by DLLHUSK.RC
//
#define IDR_MAINFRAME                   2
#define IDR_TEXTTYPE                    3
#define IDR_HELLOTYPE                   4
#define IDD_ABOUTBOX                    100
#define IDR_POPUPMENUS                  101
#define ID_DUMP_CLASSES                 32768
#define ID_DUMP_OBJECTS                 32769
#define ID_DUMP_DOCTEMPLATES            32770
#define ID_DUMP_DLLS                    32771

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         102
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
