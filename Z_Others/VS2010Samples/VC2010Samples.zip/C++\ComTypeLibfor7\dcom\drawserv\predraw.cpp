// predraw.cpp : source file that includes just the standard includes
//  stdafx.pch will be the pre-compiled header
//  stdafx.obj will contain the pre-compiled type information

#include "predraw.h"
#if _ATL_VER < 0x0700
#	include "atlimpl.cpp"
#endif