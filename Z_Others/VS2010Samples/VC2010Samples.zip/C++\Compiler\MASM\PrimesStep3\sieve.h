char *p;           // global char array used to track primes
unsigned int sz;   // range in which to search for primes (size of array)

void sieve(void);  // prototype for Sieve of Eratosthenes function
