//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by HIERSVR.RC
//
#define IDR_MAINFRAME                   1
#define IDR_HIERSVRTYPE                 2
#define IDD_ABOUTBOX                    100
#define IDP_AFXOLEINIT_FAILED           100
#define IDD_CHANGE_NAME                 101
#define IDD_ADD_NODE                    102
#define IDR_POPUPS                      103
#define IDR_HIERSVRTYPE_SRVR_EMB        105
#define IDD_CUSTZOOM                    106
#define IDR_HIERSVRTYPE_SRVR_IP         107
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_COMBO1                      1002
#define ID_CHANGE_NAME                  32768
#define ID_ADD_NODE                     32769
#define ID_IMPORT_TEXT                  32770
#define ID_VIEW_ZOOM25                  32771
#define ID_VIEW_ZOOM50                  32772
#define ID_VIEW_ZOOM75                  32773
#define ID_VIEW_ZOOM100                 32774
#define ID_VIEW_ZOOM125                 32775
#define ID_VIEW_ZOOM150                 32776
#define ID_VIEW_ZOOM175                 32777
#define ID_VIEW_ZOOM200                 32778
#define ID_VIEW_ZOOM250                 32779
#define ID_VIEW_ZOOM300                 32780
#define ID_VIEW_ZOOMCUSTOM              32781
#define ID_TREE_EXPANDONELEVEL          32783
#define ID_TREE_EXPANDBRANCH            32784
#define ID_TREE_EXPANDALL               32785
#define ID_TREE_COLLAPSEBRANCH          32786
#define ID_OPTIONS_FONT                 32787
#define ID_CANCEL_INPLACE               32788

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           200
#endif
#endif
