//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Polygon.rc
//
#define IDS_PROJNAME                    100
#define IDB_POLYCTL                     101
#define IDR_POLYCTL                     102
#define IDS_TITLEPolyProp               103
#define IDS_HELPFILEPolyProp            104
#define IDS_DOCSTRINGPolyProp           105
#define IDR_POLYPROP                    106
#define IDD_POLYPROP                    107
#define IDR_POLYGON                     108
#define IDC_SIDES                       201

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         202
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
