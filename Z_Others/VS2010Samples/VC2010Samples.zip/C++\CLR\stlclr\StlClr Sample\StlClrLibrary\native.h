#include <string>
#include <vector>

namespace Native
{
	void BubbleSort(std::vector<std::string>& v);
}