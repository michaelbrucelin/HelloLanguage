﻿//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Main_jpn.rc
//
// 版权所有(C) Microsoft Corporation。保留所有权利。
//
#define IDC_MYICON                      2
#define IDD_DIALOG                      101
#define IDD_MAIN_DIALOG                 102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDS_HELLO                       104
#define IDM_EXIT                        105
#define IDI_MAIN                        107
#define IDI_SMALL                       108
#define IDC_MAIN                        109
#define IDR_MAINFRAME                   128
#define ID_FILE_CHOOSELANGUAGE          129
#define IDC_COMBO1                      1000
#define IDC_LANGUAGE                    1001
#define IDC_LANGLABEL                   1002
#define IDC_STATIC                      -1

// 新对象的下一组默认值
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
