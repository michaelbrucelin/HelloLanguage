//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by TRACKER.RC
//
#define IDR_MAINFRAME                   2
#define IDR_TRACKETYPE                  3
#define IDD_ABOUTBOX                    100
#define IDC_EDIT1                       101
#define IDD_HANDLE_SIZE                 101
#define IDD_MIN_SIZE                    102
#define IDC_EDIT2                       102
#define ID_EDIT_SOLIDLINE               32768
#define ID_EDIT_DOTTEDLINE              32769
#define ID_EDIT_HATCHEDBORDER           32770
#define ID_EDIT_RESIZEINSIDE            32771
#define ID_EDIT_RESIZEOUTSIDE           32772
#define ID_EDIT_HATCHEDINSIDE           32773
#define ID_EDIT_ALLOWINVERT             32774
#define ID_VIEW_SETHANDLESIZE           32775
#define ID_VIEW_SETMINIMUMSIZE          32776

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         103
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
