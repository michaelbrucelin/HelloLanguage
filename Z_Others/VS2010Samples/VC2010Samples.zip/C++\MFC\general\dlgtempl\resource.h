//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dlgtemp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DLGTEMP_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_YPOS                        1007
#define IDC_WIDTH                       1008
#define IDC_HEIGHT                      1009
#define IDC_CAPTION                     1010
#define IDC_BUTTON                      1011
#define IDC_EDITCONTROL                 1012
#define IDC_STATICTEXT                  1013
#define IDC_TERMINATE                   1014
#define IDC_DEMOIT                      1015
#define IDC_SELECTEDITEM                1016
#define IDC_XPOS                        1017
#define IDC_MYBUTTON                    1018
#define IDC_MYSTATICTEXT                1019
#define IDC_MYEDITCONTROL               1020

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
