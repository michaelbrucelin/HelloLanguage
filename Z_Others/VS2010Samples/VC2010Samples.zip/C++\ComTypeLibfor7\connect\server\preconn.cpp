// preconn.cpp : source file that includes just the standard includes
//  preconn.pch will be the pre-compiled header
//  preconn.obj will contain the pre-compiled type information

#include "preconn.h"

#if _ATL_VER < 0x0700
#include "atlimpl.cpp"
#endif