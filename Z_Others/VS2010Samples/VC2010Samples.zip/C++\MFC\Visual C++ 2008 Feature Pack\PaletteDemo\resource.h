//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PaletteDemo.rc
//
#define IDS_MAIN_TOOLBAR                101
#define IDS_PALETTE                     102
#define IDR_MAINFRAME                   128
#define IDR_PALETTTYPE                  129
#define IDR_POPUP_TOOLBAR               131
#define IDR_PALETTE                     151
#define IDD_ABOUTBOX                    999
#define ID_VIEW_TOOLBARS                32771
#define ID_VIEW_TOOLS_PALETTE           32818
#define ID_PAL_CURSOR                   32819
#define ID_PAL_PICTURE                  32820
#define ID_PAL_STATIC                   32821
#define ID_PAL_EDIT                     32822
#define ID_PAL_FRAME                    32823
#define ID_PAL_BUTTON                   32824
#define ID_CPAL_CHECK                   32825
#define ID_PAL_RADIO                    32826
#define ID_PAL_COMBO                    32827
#define ID_PAL_LIST                     32828
#define ID_PAL_HSCROLL                  32829
#define ID_PAL_VSCROLL                  32830
#define ID_PAL_SPIN                     32831
#define ID_PAL_PROGRESS                 32832
#define ID_PAL_SLIDER                   32833
#define ID_PAL_KEY                      32834
#define ID_PAL_LIST_CTRL                32835
#define ID_TREE_CTRL                    32836
#define ID_PAL_TAB                      32837
#define ID_PAL_AVI                      32838
#define ID_TWO_COLUMNS                  32839
#define ID_THREE_COLUMNS                32841
#define ID_FOUR_COLUMNS                 32843
#define ID_VIEW_CUSTOMIZE               32844

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32845
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
