// premap.cpp : source file that includes just the standard includes
//  premap.pch will be the pre-compiled header
//  premap.obj will contain the pre-compiled type information

#include "premap.h"

#if _ATL_VER < 0x0700
#include "atlimpl.cpp"
#endif
