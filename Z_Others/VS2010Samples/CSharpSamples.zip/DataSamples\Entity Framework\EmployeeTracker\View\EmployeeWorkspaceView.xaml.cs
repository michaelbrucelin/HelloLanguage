﻿// 版权所有(C) Microsoft Corporation。保留所有权利。
// 此代码的发布遵从
// Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeTracker.View
{
    /// <summary>
    /// EmployeeWorkspaceView.xaml 的交互逻辑
    /// </summary>
    public partial class EmployeeWorkspaceView : UserControl
    {
        public EmployeeWorkspaceView()
        {
            InitializeComponent();
        }
    }
}
