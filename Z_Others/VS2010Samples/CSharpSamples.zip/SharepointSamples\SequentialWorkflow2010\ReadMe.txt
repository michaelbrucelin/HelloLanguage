﻿' 版权所有© Microsoft Corporation。  保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可（MS-PL，http://opensource.org/licenses/ms-pl.html）的条款。

此示例在文档上载到共享文档库之后启动一个工作流。 该工作流在任务列表中创建一个项。 
当用户将该任务设置为 100% 完成时，工作流即完成。

运行示例 

- 将项目的站点 URL 属性更改为开发系统上的有效 SharePoint 站点（即 
  http://<计算机名称>）。

如果要更改目标列表属性或其他工作流配置属性，可以通过在工作流的目标列表属性中单击按钮
来打开 SharePoint 工作流向导。 

