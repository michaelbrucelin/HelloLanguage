﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;

// 有关程序集的常规信息通过以下特性集 
// 控制。更改这些特性值可修改
// 与程序集关联的信息。
[assembly: AssemblyTitle("UserInterface")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("UserInterface")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// 将 ComVisible 设置为 false 会使此程序集中的类型 
// 对 COM 组件不可见。如果需要从 COM 访问此程序集中的某个类型，
// 请将该类型上的 ComVisible 特性设置为 true。
[assembly: ComVisible(false)]

//若要开始生成可本地化的应用程序，请 
//在 .csproj 文件中的 <PropertyGroup> 内
//设置<UICulture>编码要使用的区域性</UICulture>。例如，如果在源文件中
//使用的是简体中文，则将 <UICulture> 设置为“zh-CN”。然后取消
//对以下 NeutralResourceLanguage 特性的注释。请更新以下行中的
//“en-US”，匹配您项目文件中的 UICulture 设置。

//[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]


[assembly: ThemeInfo(
    ResourceDictionaryLocation.None, //主题专用资源字典的位置
    //(在页面或应用程序资源字典中 
    // 找不到资源时使用)
    ResourceDictionaryLocation.SourceAssembly //常规资源字典的位置
    //(在页面、应用程序或任何主题专用 
    // 资源字典中找不到资源时使用)
)]


// 程序集的版本信息由下列四个值组成:
//
//      主版本
//      次版本 
//      内部版本号
//      修订号
//
// 可以指定所有这些值，也可以使用“内部版本号”和“修订号”的默认值，
// 方法是按如下方式使用“*”:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
