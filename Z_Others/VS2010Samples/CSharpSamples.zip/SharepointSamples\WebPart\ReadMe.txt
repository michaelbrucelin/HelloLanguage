﻿' 版权所有© Microsoft Corporation。  保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可（MS-PL，http://opensource.org/licenses/ms-pl.html）的条款。


此 Visual WebPart 示例演示如何列出本地 SharePoint 服务器上的所有网站集。  
对于所选网站集，此示例显示该网站集中每个列表的统计数据。

运行示例

- 将项目的站点 URL 属性更改为开发计算机上的有效 SharePoint 站点（即 
  http://<计算机名称>）

运行 (F5) 示例时，将打开一个浏览器窗口，其中显示开发站点的主页。  
从“网站操作”菜单中选择“更多选项...”。 然后创建 Web 部件页。  
在命名并创建此页后，向其中添加 Web 部件。
