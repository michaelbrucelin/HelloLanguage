﻿using System.Reflection;
using System.Runtime.CompilerServices;
// 此代码和信息“按原样”提供，不提供任何形式的
// 明示或暗示担保，包括但不限于
// 对适销性和/或为特定目的所做的
// 的暗示担保。
//
// 版权所有(C) Microsoft Corporation。保留所有权利。

// 有关程序集的常规信息通过以下特性集 
// 控制。更改这些特性值可修改
// 与程序集关联的信息。
[assembly: AssemblyTitle("SequentialWorkflow")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("SequentialWorkflow")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2009")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]