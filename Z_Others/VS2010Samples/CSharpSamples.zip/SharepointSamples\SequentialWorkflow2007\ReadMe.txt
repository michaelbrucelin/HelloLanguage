﻿' 版权所有© Microsoft Corporation。  保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可（MS-PL，http://opensource.org/licenses/ms-pl.html）的条款。

若要使此示例可以在 Microsoft Office SharePoint Server (MOSS) 2007 
上运行，必须对工作流项目进行以下更改：

- 将调试站点 URL 属性更改为“http://localhost/Docs/”或开发系统上的其他有效 
  SharePoint 站点。

- 将要与工作流关联的目标库或列表更改为“Documents”或指定为调试站点 URL 
  的站点上的其他列表。


可以在 SharePoint 工作流向导中设置这些属性。 若要打开 SharePoint 
工作流向导，请在解决方案资源管理器中右击项目节点并选择“SharePoint 
调试设置”。调试站点 URL 设置位于该向导第一页上，目标库或列表设置位于第二页上。

