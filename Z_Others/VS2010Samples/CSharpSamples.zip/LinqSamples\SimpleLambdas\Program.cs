﻿// 版权所有(C) Microsoft Corporation。保留所有权利。
// 此代码的发布遵从
// Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
//
//版权所有(C) Microsoft Corporation。保留所有权利。

using System;
using System.Collections.Generic;
using System.Linq;

// 有关其他信息，请参阅 ReadMe.html
class Program
{
    static void Main()
    {
        Samples.Sample1();        
        Console.ReadLine();
    }
}
