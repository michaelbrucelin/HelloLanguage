﻿// 此代码和信息“按原样”提供，不提供任何形式的
// 明示或暗示担保，包括但不限于
// 对适销性和/或为特定目的所做的
// 的暗示担保。
//
// 版权所有(C) Microsoft Corporation。保留所有权利。

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

[assembly: AssemblyTitle("UiManagerOutlookAddIn")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("UiManagerOutlookAddIn")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2006")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("17E84F95-E185-48bb-8B6F-611A88395CDD")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: CLSCompliant(true)]

[assembly: NeutralResourcesLanguage("en-us")]
