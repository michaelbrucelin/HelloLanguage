﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
'==============================================================================
' 示例
' 此示例显示共同使用的“In”和“Out”类型。
'
' 此处，我们有一个管道，其中的元素为 ICollection。
'    IList 是一个 ICollection，不是 IEnumerable
' 但是，当我们向公共成员授予“reader”(“Out”)访问权限时，我们强制其实现，从而使
' 读取者只能假定那些元素为 IEnumerable。
' 而当我们授予“写入者”(“In”)访问权限，我们强制实现它，从而使写入者必须
' 始终放在 IList 中。
'
' 这从两个方面为我们的代码提供了未来的保证: 它强制
' 实现提供 IList，以防未来我们要向客户端公开更多权限；
' 但它并没有对未来实现将要支持的客户端
' 做出公开的承诺。
'==============================================================================
Option Strict On

Interface IWritable(Of In Tin)
    Sub Push(ByVal value As Tin)
End Interface

Interface IReadable(Of Out Tout)
    Function Pop() As Tout
End Interface

Class MyPipe(Of T)
    Implements IWritable(Of T)
    Implements IReadable(Of T)

    Dim contents As New Stack(Of T)

    '在“in”位置使用了“T”
    Public Sub Push(ByVal value As T) Implements IWritable(Of T).Push
        contents.Push(value)
    End Sub

    '在“out”位置使用了“T”
    Public Function Pop() As T Implements IReadable(Of T).Pop
        Return contents.Pop()
    End Function
End Class

