﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。

Public Class ThisDocument

    Private myActionsPane As New ActionsPaneControl1

    Private Sub ThisDocument_Startup() Handles Me.Startup
        'TODO: 删除此行代码以移除“NorthwindDataSet.Employees”的默认 AutoFill。
        If Me.NeedsFill("NorthwindDataSet") Then
            Me.EmployeesTableAdapter.Fill(Me.NorthwindDataSet.Employees)
        End If
        Me.ActionsPane.Controls.Add(MyActionsPane)
    End Sub

    Private Sub ThisDocument_Shutdown() Handles Me.Shutdown

    End Sub

End Class
