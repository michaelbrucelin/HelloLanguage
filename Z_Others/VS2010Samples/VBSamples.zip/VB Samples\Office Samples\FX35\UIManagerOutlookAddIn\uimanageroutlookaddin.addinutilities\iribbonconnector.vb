﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。


Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Runtime.InteropServices
Imports Office = Microsoft.Office


' 此接口由于其 Office 属性的缘故不符合 CLS。
<ComVisible(True)> _
<InterfaceType(ComInterfaceType.InterfaceIsDual)> _
<Guid("43189577-8667-4c8f-8167-EBF23CC285CB")> _
<CLSCompliant(False)> _
Public Interface IRibbonConnector
    Property Ribbon() As Office.Core.IRibbonUI
End Interface


' Regasm 将不会注册仅包含接口的程序集。
' 需要定义一个 COM 可创建类以获取类型库。
' 我们不希望使用此类来执行任何操作，因为
' 我们正在另一个程序集中实现该接口。
<ComVisible(True)> _
<ClassInterface(ClassInterfaceType.None)> _
<CLSCompliant(False)> _
Public Class RibbonConnectorPlaceholder
    Implements IRibbonConnector

    Public Property Ribbon() As Office.Core.IRibbonUI Implements IRibbonConnector.Ribbon
        Get
            Return Nothing
        End Get
        Set(ByVal value As Office.Core.IRibbonUI)
        End Set
    End Property

End Class
