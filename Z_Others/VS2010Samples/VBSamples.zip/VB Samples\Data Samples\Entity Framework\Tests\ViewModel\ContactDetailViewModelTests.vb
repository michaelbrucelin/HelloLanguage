﻿' 版权所有(C) Microsoft Corporation。保留所有权利。


Imports Microsoft.VisualBasic
Imports System.Collections.Generic
Imports EmployeeTracker.Model
Imports EmployeeTracker.ViewModel
Imports Microsoft.VisualStudio.TestTools.UnitTesting

Namespace Tests.ViewModel

    ''' <summary>
    ''' 针对 ContactDetailViewModel 的单元测试
    ''' </summary>
    <TestClass>
    Public Class ContactDetailViewModelTests
        ''' <summary>
        ''' 验证 BuildViewModel 是否可以创建所有的联系人详细信息类型
        ''' </summary>
        <TestMethod>
        Public Sub BuildViewModel()
            Dim p As New Phone()
            Dim e As New Email()
            Dim a As New Address()

            Dim pvm = ContactDetailViewModel.BuildViewModel(p)
            Assert.IsInstanceOfType(pvm, GetType(PhoneViewModel), "Factory method created wrong ViewModel type.")
            Assert.AreEqual(p, pvm.Model, "Underlying model object on ViewModel is not correct.")

            Dim evm = ContactDetailViewModel.BuildViewModel(e)
            Assert.IsInstanceOfType(evm, GetType(EmailViewModel), "Factory method created wrong ViewModel type.")
            Assert.AreEqual(e, evm.Model, "Underlying model object on ViewModel is not correct.")

            Dim avm = ContactDetailViewModel.BuildViewModel(a)
            Assert.IsInstanceOfType(avm, GetType(AddressViewModel), "Factory method created wrong ViewModel type.")
            Assert.AreEqual(a, avm.Model, "Underlying model object on ViewModel is not correct.")
        End Sub

        ''' <summary>
        ''' 验证 BuildViewModel 在处理无法识别的类型时是否不会引发异常
        ''' </summary>
        <TestMethod>
        Public Sub BuildViewModelUnknownType()
            Dim f = New FakeContactDetail()
            Dim fvm = ContactDetailViewModel.BuildViewModel(f)
            Assert.IsNull(fvm, "BuildViewModel should return null when it doesn't know how to handle a type.")
        End Sub

        ''' <summary>
        ''' 验证对于 null 无效的情况是否引发 NullArgumentExceptions
        ''' </summary>
        <TestMethod>
        Public Sub CheckNullArgumentExceptions()
            Utilities.CheckNullArgumentException(Sub() ContactDetailViewModel.BuildViewModel(Nothing), "detail", "BuildViewModel")
        End Sub

        ''' <summary>
        ''' 用于测试 BuildViewModelUnknownType 的虚设联系人类型
        ''' </summary>
        Private Class FakeContactDetail
            Inherits ContactDetail
            ''' <summary>
            ''' 为用法字段获取有效值
            ''' 存根实现，只返回 null
            ''' </summary>
            Public Overrides ReadOnly Property ValidUsageValues() As IEnumerable(Of String)
                Get
                    Return Nothing
                End Get
            End Property
        End Class
    End Class
End Namespace
