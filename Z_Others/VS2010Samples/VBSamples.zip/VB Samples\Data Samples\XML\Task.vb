﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
Public Class Task

    '指向指定任务的实现的委托
    Public Delegate Function ExecuteTask() As String

    Private methodValue As ExecuteTask
    Private nameValue As String

    Public Sub New(ByVal newName As String, ByVal newMethod As ExecuteTask)
        Name = newName
        Method = newMethod
    End Sub

    Public Overrides Function ToString() As String
        Return Name
    End Function

    Public Property Method() As ExecuteTask
        Get
            Return methodValue
        End Get
        Set(ByVal Value As ExecuteTask)
            methodValue = Value
        End Set
    End Property

    Public Property Name() As String
        Get
            Return nameValue
        End Get
        Set(ByVal Value As String)
            nameValue = Value
        End Set
    End Property

End Class
