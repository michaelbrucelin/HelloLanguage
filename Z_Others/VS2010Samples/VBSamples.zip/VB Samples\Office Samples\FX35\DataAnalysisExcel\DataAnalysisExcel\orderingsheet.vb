﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。

Imports System
Imports System.Windows.Forms
Imports System.Globalization
Imports Excel = Microsoft.Office.Interop.Excel
 
Class OrderingSheet
    Friend Enum StatHeadings
        DailySales = 0
        Required
        CurrentInventory
        ProjectInventory
        OrderQuanity
    End Enum

    Private headers() As String = _
    { _
        My.Resources.MaxDailySalesHeader, _
        My.Resources.ProjectedSalesHeader, _
        My.Resources.CurrentInventoryHeader, _
        My.Resources.ProjectedInventoryHeader, _
        My.Resources.OrderQuantityHeader _
    }

    Dim deliveryDate As DateTime

    Dim nextScheduledDeliveryDate As DateTime

    Dim orderDate As DateTime

    Dim worksheet As Excel.Worksheet

    Const orderDateAddress As String = "$B$4"
    Const pivotTableAddress As String = "$B$10"

    Public Sub New(ByVal isUnscheduled As Boolean)
        If (Not Globals.DataSet.IsLastDayComplete()) Then
            Throw New ApplicationException(Globals.ThisWorkbook.IncompleteDataMessage)
        End If

        Me.orderDate = Globals.DataSet.MaxDate

        Dim worksheetName As String

        If (isUnscheduled) Then
            worksheetName = ExcelHelpers.CreateValidWorksheetName(String.Format(CultureInfo.CurrentUICulture, My.Resources.UnscheduledOrderSheetName, Me.orderDate.ToShortDateString()))
            nextScheduledDeliveryDate = ComputeWeeklyDeliveryDate()
        Else
            worksheetName = ExcelHelpers.CreateValidWorksheetName(String.Format(CultureInfo.CurrentUICulture, My.Resources.WeeklyOrderSheetName, Me.orderDate.ToShortDateString()))
            nextScheduledDeliveryDate = deliveryDate.AddDays(7)
        End If

        Dim worksheet As Excel.Worksheet = Nothing

        ' 如果该名称已经存在，则在创建工作表时将引发异常。
        Try
            worksheet = ThisWorkbook.CreateWorksheet(worksheetName)
        Catch ex As Exception
            Dim message As String

            If isUnscheduled Then
                message = String.Format(CultureInfo.CurrentUICulture, My.Resources.UnscheduledOrderSheetCreationError, worksheetName)
            Else
                message = String.Format(CultureInfo.CurrentUICulture, My.Resources.WeeklyOrderSheetCreationError, worksheetName)
            End If

            Throw New ApplicationException(message, ex)
        End Try

        Me.worksheet = worksheet

        CreateOrder(isUnscheduled)
    End Sub

    Private Function ComputeUnscheduledDeliveryDate() As DateTime
        Return Me.orderDate.AddDays(1).Date
    End Function

    Private Function ComputeWeeklyDeliveryDate() As DateTime
        Return Globals.DataSet.NextWeeklyDeliveryDate
    End Function

    Private Sub CreateOrder(ByVal isUnscheduled As Boolean)
        If (isUnscheduled) Then
            Me.deliveryDate = ComputeUnscheduledDeliveryDate()
        Else
            Me.deliveryDate = ComputeWeeklyDeliveryDate()
        End If

        ' 这会创建一个数据透视表，其中包含 
        ' 与冰淇淋的销售量有关的信息。
        Me.PopulateDateInformation(Me.orderDate)

        Dim pivotTable As Excel.PivotTable = Me.CreatePivotTable()

        Me.AddCalculations(pivotTable)

    End Sub

    Private Sub AddCalculations(ByVal pivotTable As Excel.PivotTable)
        ' 如果该工作表当前未处于活动状态，
        ' 则激活该工作表。

        ' 获取构成数据透视表的范围。
        Dim tableRange As Excel.Range = pivotTable.TableRange1
        Dim dataRange As Excel.Range = pivotTable.DataBodyRange

        ' 获取需要添加到数据透视表后面的
        ' 每个列。
        Dim values As System.Array = System.Enum.GetValues(GetType(StatHeadings))

        ' 确定数据透视表的左上角单元格。
        Dim tableStartCell As Excel.Range = ExcelHelpers.GetCellFromRange(tableRange, 1, 1)

        ' 获取数据透视表末尾相应行中的
        ' 第一个可用单元格。
        Dim nextHeader As Excel.Range = tableStartCell.End(Excel.XlDirection.xlDown).End(Excel.XlDirection.xlToRight).End(Excel.XlDirection.xlUp).Next

        ' 确定构成当前列的计算字段的
        ' 边界单元格。
        Dim colStart As Excel.Range = ExcelHelpers.GetCellFromRange(nextHeader, 2, 1)

        Dim colEnd As Excel.Range = colStart.Offset(dataRange.Rows.Count - 1, 0)

        ' 对于需要添加的每一列，
        ' 填充其统计信息和标题。

        Dim i As Integer
        For Each i In values
            nextHeader.Value2 = Me.headers(i)
            Me.PopulateStatColumn(i, colStart, colEnd)
            nextHeader = nextHeader.Next
            colStart = colStart.Next
            colEnd = colEnd.Next
        Next
    End Sub

    Private Sub PopulateStatColumn(ByVal column As Integer, ByVal startCell As Excel.Range, ByVal endCell As Excel.Range)
        Try
            ' 确定需要用数据填充的范围。
            Dim twoLines As Excel.Range = startCell.Resize(2, 1)

            twoLines.Merge(System.Type.Missing)

            Dim fillRange As Excel.Range = Me.worksheet.Range(startCell, endCell)
            endCell.Select()

            Select Case column
                Case StatHeadings.DailySales
                    ' 填充日销售额列。
                    ' 获取包含标准偏差和
                    ' 平均值的单元格的地址。
                    Dim average As Excel.Range = startCell.Previous
                    Dim averageAddress As String = average.Address(False, False, Excel.XlReferenceStyle.xlA1)
                    Dim standardDev As Excel.Range = average.Offset(1, 0)
                    Dim standardDevAddress As String = standardDev.Address(False, False, Excel.XlReferenceStyle.xlA1)

                    ' 设置该列的公式。
                    startCell.Formula = "=" + averageAddress + "+ (2*" + standardDevAddress + ")"

                    ' 格式“0.00”- 两个小数位。
                    startCell.NumberFormat = "0.00"
                    twoLines.AutoFill(fillRange, Excel.XlAutoFillType.xlFillDefault)
                    Exit Select

                Case StatHeadings.Required
                    ' 填充所需的列。
                    ' 确定包含预期销售额的
                    ' 单元格的地址。
                    Dim expectedSales As Excel.Range = startCell.Previous
                    Dim salesAddress As String = expectedSales.Address(False, False, Excel.XlReferenceStyle.xlA1)

                    ' 确定交货前需要多少 
                    ' 库存。
                    ' 确定交货前的天数。
                    Dim waitDays As Integer = Me.GetDaysToDelivery()

                    startCell.Formula = "=" + waitDays.ToString() + "*" + salesAddress

                    ' 格式“0.00”- 两个小数位。
                    startCell.NumberFormat = "0.00"
                    twoLines.AutoFill(fillRange, Excel.XlAutoFillType.xlFillDefault)

                Case StatHeadings.CurrentInventory
                    ' 填充当前库存列。
                    ' 从日记中获取上一天的范围。
                    Dim count As Integer = (endCell.Row - startCell.Row + 1) \ 2
                    Dim currentCell As Excel.Range = startCell

                    For row As Integer = 0 To count - 1
                        Dim flavorCell As Excel.Range = currentCell.Offset(0, 0 - 5)


                        Dim flavor As String = ExcelHelpers.GetValueAsString(flavorCell)
                        Dim inventory As Integer

                        inventory = Globals.DataSet.Sales.FindBy_DateFlavor(Globals.DataSet.MaxDate, flavor).Inventory

                        currentCell.Value2 = inventory

                        If (row <> 0) Then
                            Dim twoCells As Excel.Range = currentCell.Resize(2, 1)

                            twoCells.Merge(System.Type.Missing)
                            currentCell = twoCells
                        End If

                        currentCell = currentCell.Offset(1, 0)
                    Next
                    Exit Select

                Case StatHeadings.ProjectInventory

                    ' 获取预计销售额和
                    ' 当前库存的地址。
                    Dim currentInventory As Excel.Range = startCell.Previous
                    Dim required As Excel.Range = currentInventory.Previous
                    Dim currentInventoryAddress As String = currentInventory.Address(False, False, Excel.XlReferenceStyle.xlA1)
                    Dim requiredAddress As String = required.Address(False, False, Excel.XlReferenceStyle.xlA1)

                    ' 确定交货日期的 
                    ' 预计库存。
                    startCell.Formula = "=MAX(0," + currentInventoryAddress + "-" + requiredAddress + ")"

                    ' 格式“0.00”- 两个小数位。
                    startCell.NumberFormat = "0.00"
                    twoLines.AutoFill(fillRange, Excel.XlAutoFillType.xlFillDefault)
                    Exit Select

                Case StatHeadings.OrderQuanity
                    ' 确定预计库存和
                    ' 所需库存量的地址。
                    Dim projectedInventory As Excel.Range = startCell.Previous
                    Dim needed As Excel.Range = projectedInventory.Previous.Previous
                    Dim projectedInventoryAddress As String = projectedInventory.Address(False, False, Excel.XlReferenceStyle.xlA1)
                    Dim neededAddress As String = needed.Address(False, False, Excel.XlReferenceStyle.xlA1)

                    ' 确定每一项所需的订货量。
                    startCell.Formula = "=" + neededAddress + "-" + projectedInventoryAddress

                    ' 格式“0.00”- 两个小数位。
                    startCell.NumberFormat = "0.00"
                    twoLines.AutoFill(fillRange, Excel.XlAutoFillType.xlFillDefault)
                    Exit Select

                Case Else
                    Exit Select
            End Select
        Catch ex As Exception
            Debug.WriteLine(ex.ToString())
            Throw
        End Try
    End Sub

    Private Function GetDaysToDelivery() As Integer

        ' 此方法确定距离下一个
        ' 计划交货日期的天数。
        '这是估计已订货天数所需的。

        Dim difference As TimeSpan = Me.nextScheduledDeliveryDate - Me.deliveryDate

        Return difference.Days
    End Function

    Private Function CreatePivotTable() As Excel.PivotTable
        Dim generator As TextFileGenerator = New TextFileGenerator(Globals.DataSet.Sales)
        Dim pivotTable As Excel.PivotTable = Nothing

        Try

            ' 获取新的数据透视表的目标。
            Dim destination As Excel.Range = Me.worksheet.Range(pivotTableAddress)

            pivotTable = Globals.ThisWorkbook.CreateSalesPivotTable(destination, generator.FullPath)

            ' 将新的数据透视表的属性调整为
            ' 所需方式的格式信息。
            pivotTable.ColumnGrand = False
            pivotTable.RowGrand = False

            ' 在数据透视表中，添加所需的 
            ' 行和列。
            pivotTable.AddFields("Flavor")

            Dim soldField As Excel.PivotField = pivotTable.AddDataField(pivotTable.PivotFields("Sold"), My.Resources.AverageOfUnitsSold, Excel.XlConsolidationFunction.xlAverage)

            ' 在数据透视表中设置所需数据的视图。
            ' 格式“0.0”- 一个小数位。
            soldField.NumberFormat = "0.0"

            Dim profitField As Excel.PivotField = pivotTable.AddDataField(pivotTable.PivotFields("Sold"), My.Resources.StdDevOfUnitsSold, Excel.XlConsolidationFunction.xlStDev)

            ' 在数据透视表中设置所需数据的视图。
            ' 格式“0.00”- 两个小数位。
            profitField.NumberFormat = "0.00"

            ' 隐藏创建数据透视表时添加的两个浮动栏。
            Globals.ThisWorkbook.ShowPivotTableFieldList = False
            Me.worksheet.Application.CommandBars("PivotTable").Visible = False

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
            Throw
        Finally
            generator.Dispose()
        End Try

        Return pivotTable
    End Function


    Private Sub PopulateDateInformation(ByVal orderDate As DateTime)
        ' 此方法用下一个订货日期及其相应的 
        ' 交货日期来填充工作表。
        ' 获取下一个订货日期并填充该日期。
        Dim orderDateCell As Excel.Range = worksheet.Range(orderDateAddress)

        orderDateCell.Value2 = My.Resources.OrderDateHeader
        orderDateCell.Next.Value2 = orderDate.ToShortDateString()

        Dim deliveryDateCell As Excel.Range = ExcelHelpers.GetCellFromRange(orderDateCell, 2, 1)

        deliveryDateCell.Value2 = My.Resources.DeliveryDateHeader
        deliveryDateCell.Next.Value2 = Me.deliveryDate.ToShortDateString()
    End Sub

End Class
