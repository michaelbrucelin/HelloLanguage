﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。


Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Runtime.InteropServices
Imports Outlook = Microsoft.Office.Interop.Outlook


' 此接口由于其 Office 属性的缘故不符合 CLS。
<ComVisible(True)> _
<InterfaceType(ComInterfaceType.InterfaceIsDual)> _
<Guid("53ED8FA5-DBAD-40c4-8068-F20E7858DEB6")> _
<CLSCompliant(False)> _
Public Interface IFormRegionControls
    Property Inspector() As Outlook.Inspector
    Sub SetControlText(ByVal controlName As String, ByVal text As String)
End Interface
