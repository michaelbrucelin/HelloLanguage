﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。


Public Class Helper

    ' 返回出现在 RSS 项的标题中的“查看文章”链接的 URL。
    Public Shared Function ParseUrl(ByVal item As Outlook.PostItem) As String

        Const lookUpText As String = "HYPERLINK"
        Const articleStr As String = "View article"
        Dim body As String = item.Body

        Dim index As Integer = body.IndexOf(lookUpText, 0, body.Length)
        Dim endIndex As Integer = 0

        ' 在正文中查找“HYPERLINKS”并将范围缩小到“查看文章...”链接。
        While True
            endIndex = body.IndexOf(articleStr, index, body.Length - index)
            Dim nextIndex As Integer = body.IndexOf(lookUpText, index + 1, body.Length - (index + 1))

            If nextIndex > index And nextIndex < endIndex Then
                index = nextIndex
            Else
                Exit While
            End If
        End While

        ' 获取文章的链接。
        Dim url As String = body.Substring(index + lookUpText.Length + 1, endIndex - index - (lookUpText.Length + 1))

        url = url.Trim("""")

        Return url

    End Function

End Class
