﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
Class CustomerExpanded

    ' 此示例定义一个等同于 Customer_AutoImplemented.vb
    '  中的 Customer 的类，不同之处在于属性
    ' 不是自动实现的。

    Private _name As String
    Property Name() As String
        Get
            Return _name
        End Get
        Set(ByVal value As String)
            _name = value
        End Set
    End Property

    Private _customerID As Integer? = -1
    Property CustomerID() As Integer?
        Get
            Return _customerID
        End Get
        Set(ByVal value As Integer?)
            _customerID = value
        End Set
    End Property

    Private _city As String
    Property City() As String
        Get
            Return _city
        End Get
        Set(ByVal value As String)
            _city = value
        End Set
    End Property

    Private _state As String
    Property State() As String
        Get
            Return _state
        End Get
        Set(ByVal value As String)
            _state = value
        End Set
    End Property


    ' GetCustomerList 生成并返回 CustomerExpanded 对象的列表。
    ' 与 Customer_AutoImplemented.vb 中 GetCustomerList 函数进行比较，
    ' 它使用集合初始值设定项生成了相同的列表。

    Shared Function GetCustomerList() As IEnumerable(Of CustomerExpanded)

        Dim custList As New System.Collections.Generic.List(Of CustomerExpanded)
        Dim cust1 As New CustomerExpanded With {.Name = "Adventure Works", _
                                                .CustomerID = 13302, _
                                                .City = "Louisville", _
                                                .State = "Kentucky"}
        Dim cust2 As New CustomerExpanded With {.Name = "Coho Winery", _
                                                .CustomerID = 38847, _
                                                .City = "Springfield", _
                                                .State = "Missouri"}
        Dim cust3 As New CustomerExpanded With {.Name = "Proseware, Inc.", _
                                                .CustomerID = 19724, _
                                                .City = "Los Angeles", _
                                                .State = "California"}
        Dim cust4 As New CustomerExpanded With {.Name = "Fourth Coffee", _
                                                .CustomerID = 60442, _
                                                .City = "Honolulu", _
                                                .State = "Hawaii"}
        Dim cust5 As New CustomerExpanded With {.Name = "Margie's Travel", _
                                                .CustomerID = 67420, _
                                                .City = "Redmond", _
                                                .State = "Washington"}
        Dim cust6 As New CustomerExpanded With {.Name = "Wingtip Toys", _
                                                .CustomerID = 39871, _
                                                .City = "Springfield", _
                                                .State = "Illinois"}
        Dim cust7 As New CustomerExpanded With {.Name = "City Power & Light", _
                                                .CustomerID = 74739, _
                                                .City = "Redmond", _
                                                .State = "Washington"}
        Dim cust8 As New CustomerExpanded With {.Name = "Lucerne Publishing", _
                                                .CustomerID = 55061, _
                                                .City = "Redmond", _
                                                .State = "Washington"}

        custList.Add(cust1)
        custList.Add(cust2)
        custList.Add(cust3)
        custList.Add(cust4)
        custList.Add(cust5)
        custList.Add(cust6)
        custList.Add(cust7)
        custList.Add(cust8)

        Return custList

    End Function

End Class



