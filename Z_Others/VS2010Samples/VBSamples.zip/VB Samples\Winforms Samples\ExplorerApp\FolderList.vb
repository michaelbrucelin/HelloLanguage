﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
Imports System.Windows.Forms

' 需要此类是因
' System.Windows.Forms.Design.FolderNameEditor.FolderBrowser 受到保护而无法
' 在此上下文中访问该对话框。从该类派生一个 Public 类就可以
' 在代码中使用该对话框。
Public Class FolderBrowser
    Inherits System.Windows.Forms.Design.FolderNameEditor

    Public Shared Function ShowDialog() As String
        Dim folders As New FolderBrowser()
        folders.Description = "Select a Directory to Scan"
        folders.Style = Design.FolderNameEditor.FolderBrowserStyles.RestrictToFilesystem
        folders.ShowDialog()

        Return folders.DirectoryPath

    End Function
End Class
