﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
Imports Microsoft.VisualBasic.FileIO

Public Class MoveDirectoryPanel
    Inherits FileSystemSample.TaskPanelBase

#Region " Windows 窗体设计器生成的代码 "

    Public Sub New()
        MyBase.New()

        ' 此调用是 Windows 窗体设计器所必需的。
        InitializeComponent()

        ' 在 InitializeComponent() 调用之后添加任何初始化

    End Sub

    ' 窗体重写释放，以清理组件列表。
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    ' 注意: 以下过程是 Windows 窗体设计器所必需的
    ' 可以使用 Windows 窗体设计器修改它。  
    ' 不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerNonUserCode()> Private Sub InitializeComponent()
        '
        'DescriptionTextBox
        '
        Me.DescriptionTextBox.AutoSize = False
        Me.DescriptionTextBox.Multiline = True
        Me.DescriptionTextBox.Size = New System.Drawing.Size(568, 55)
        Me.DescriptionTextBox.Text = "Moves a directory (including its head) under the target specified target.  If a d" & _
            "irectory with the same name exists under the target directory, the contents will" & _
            " be merged.  Windows shell dialogs may be enabled by setting showUI = true"
        '
        'ExececuteMethodButton
        '
        '
        'ResetValuesButton
        '
        '
        'MoveDirectoryPanel
        '
        Me.Name = "MoveDirectoryPanel"

    End Sub

#End Region

    Private Shared panelInstance As MoveDirectoryPanel
    Friend WithEvents sourceDirectoryChooser As New DirectoryChooser()
    Friend WithEvents targetDirectoryChooser As New DirectoryChooser()
    Friend WithEvents showUIComboBox As New ComboBox()
    Friend WithEvents onUserCancelComboBox As New ComboBox()

    ''' <summary>
    ''' 获取该面板的全局实例
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function GetInstance() As MoveDirectoryPanel
        If (panelInstance Is Nothing) Then
            panelInstance = New MoveDirectoryPanel()
        End If
        Return panelInstance
    End Function

    ''' <summary>
    ''' 创建该面板并为 My.Computer.FileSystem.MoveDirectory() 的每个参数添加一个控件
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub MoveDirectoryPanel_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        InitializeUserControls()
        MyBase.AddParameter("sourceDirectoryName", sourceDirectoryChooser)
        MyBase.AddParameter("destinationDirectoryName", targetDirectoryChooser)
        MyBase.AddParameter("showUI", showUIComboBox)
        MyBase.AddParameter("onUserCancel", onUserCancelComboBox)
    End Sub


    ''' <summary>
    ''' 用所需的控件创建该面板。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeUserControls()
        MyBase.MethodNameLabel.Text = "My.Computer.FileSystem.MoveDirectory("

        sourceDirectoryChooser.Reset()
        targetDirectoryChooser.Reset()

        showUIComboBox.Items.AddRange(New String() {"True", "False"})
        showUIComboBox.AutoSize = True
        showUIComboBox.SelectedItem = "False"
        showUIComboBox.DropDownStyle = ComboBoxStyle.DropDownList

        onUserCancelComboBox.Items.AddRange(New String() {"Do Nothing", "Throw Exception"})
        onUserCancelComboBox.AutoSize = True
        onUserCancelComboBox.SelectedItem = "Throw Exception"
        onUserCancelComboBox.DropDownStyle = ComboBoxStyle.DropDownList

    End Sub

    ''' <summary>
    ''' 使用 My.Computer.FileSystem.MoveDirectory() 移动指定的目录
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ExececuteMethodButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExececuteMethodButton.Click
        Try
            My.Computer.FileSystem.MoveDirectory( _
                                    sourceDirectoryName:=Me.sourceDirectoryChooser.Directory, _
                                    destinationDirectoryName:=Me.targetDirectoryChooser.Directory, _
                                    showUI:=CType(UIOption.Parse(GetType(UIOption), CType(Me.showUIComboBox.SelectedItem, String)), UIOption), _
                                    onUserCancel:=ParseUICancelOption(Me.onUserCancelComboBox))
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    ''' <summary>
    ''' 将该面板重置为其初始状态
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ResetValuesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResetValuesButton.Click
        InitializeUserControls()
    End Sub
End Class
