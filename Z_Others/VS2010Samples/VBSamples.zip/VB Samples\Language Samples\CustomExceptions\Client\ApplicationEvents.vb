﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
Imports TailspinToysCRM

Namespace My

    ' 以下事件可用于 MyApplication：
    ' 
    ' Startup: 应用程序启动时在创建启动窗体之前引发。
    ' Shutdown：在关闭所有应用程序窗体后引发。如果应用程序异常终止，则不会引发此事件。
    ' UnhandledException: 在应用程序遇到未经处理的异常时引发。
    ' StartupNextInstance: 在启动单实例应用程序且应用程序已处于活动状态时引发。
    ' NetworkAvailabilityChanged: 在连接或断开网络连接时引发。
    Partial Friend Class MyApplication

        Private Sub MyApplication_UnhandledException(ByVal sender As Object, ByVal e As Microsoft.VisualBasic.ApplicationServices.UnhandledExceptionEventArgs) Handles Me.UnhandledException
            If My.Forms.MainForm.ShouldTrapUnhandledException Then
                ' 此时，您应该能够指出如何操作。
                ' 您应该记录错误，显示消息框，并发送电子邮件。
                ' 真正关键的是使用类似下面的代码评估接收到的
                ' 异常。

                ' 注意，您应该小心谨慎。如果这里有未捕获的异常，
                ' 则应该查看 JIT 调试对话框，而不是 Windows 窗体处理程序。
                ' 取消对下面的行的注释，然后进行查看。
                ' Throw New ArgumentException("Oopss! I did it again!")

                Dim exp As Exception = e.Exception

                If TypeOf exp Is CustomerException Then
                    ' 检查是否有任何 CustomerException
                ElseIf TypeOf exp Is ApplicationException Then
                    ' 检查是否有任何可能的应用程序异常
                ElseIf TypeOf exp Is ArithmeticException Then
                    ' 如果运行 cmdUntrapped_Click 中的代码，
                    ' 则应该查看此对话框。
                    ' 取消对此行的注释以进行验证。
                    ' MsgBox(exp.Message, MsgBoxStyle.OKOnly, exp.Source)
                ElseIf TypeOf exp Is SystemException Then
                    ' 检查是否有任何可能的系统异常
                Else
                    ' 最后只剩下一般的 System.Exception
                End If

                Dim message As String
                message = String.Format("An untrapped error occurred.{0}The error message was:{0}{1}", vbCrLf, exp.Message)

                MsgBox(message, MsgBoxStyle.OkOnly, "Global Exception Trap")
                ' 尝试让应用程序继续执行。
                e.ExitApplication = False
            Else
                ' 如果全局异常处理已关闭，则重新引发异常
                Throw e.Exception
            End If
            


        End Sub
    End Class

End Namespace

