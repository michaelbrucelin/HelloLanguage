﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
Public Class PhoneTextBox
    Inherits RegExTextBox

    Private Sub SetValidation()
        ' 为 ValidationExpression 设置默认值，
        ' 以使此控件确认
        'TextBox 的内容是否像电话号码。
        Me.ValidationExpression = "^((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}$"
        Me.ErrorMessage = "The phone number must be in the form of (555) 555-1212 or 555-555-1212."
    End Sub
End Class
