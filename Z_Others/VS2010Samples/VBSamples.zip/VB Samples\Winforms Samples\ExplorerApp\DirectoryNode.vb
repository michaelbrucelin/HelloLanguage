﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此类仅扩展 TreeNode 类，方法是通过添加“Size”字段来支持按颜色指示
' 目录大小。
Public Class DirectoryNode
    Inherits TreeNode

    Public Size As Long

End Class

