﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。


Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.Text
Imports System.Windows.Forms
Imports Office = Microsoft.Office
Imports Outlook = Microsoft.Office.Interop.Outlook

Public Class UserInterfaceElements

    Private _items As List(Of UserInterfaceContainer)

    Public Sub New()
        _items = New List(Of UserInterfaceContainer)
    End Sub

    Public Sub Add(ByVal uiContainer As UserInterfaceContainer)
        _items.Add(uiContainer)
        AddHandler uiContainer.InspectorClose, AddressOf uiContainer_InspectorClose
    End Sub

    ' 关闭检查器后，窗体区域也会关闭，因此
    ' 我们需要从集合中移除此实例。
    Public Sub uiContainer_InspectorClose(ByVal sender As Object, ByVal e As EventArgs)
        _items.Remove(sender)
    End Sub

    Public Function Remove(ByVal uiContainer As UserInterfaceContainer) As Boolean
        Return _items.Remove(uiContainer)
    End Function

    ' 通过附加给定的 FormRegionControls 对象，更新集合中
    ' 由给定检查器指示的 UI 容器对象。
    ' 此方法由于其 Office 参数的缘故不符合 CLS。
    <CLSCompliant(False)> _
    Public Function AttachFormRegion( _
    ByVal inspector As Outlook.Inspector, _
    ByVal formRegionControls As IFormRegionControls) As Boolean
        Dim updateOK As Boolean
        updateOK = False

        ' 在容器的集合中查找此检查器。
        Dim uiContainer As UserInterfaceContainer
        uiContainer = GetUIContainerForInspector(inspector)
        If (Not uiContainer Is Nothing) Then
            uiContainer.FormRegionControls = formRegionControls
            updateOK = True
        End If

        Return updateOK
    End Function

    ' 在给定检查器的情况下，查找匹配的 UI 容器对象。
    ' 此方法由于其 Office 参数的缘故不符合 CLS。
    <CLSCompliant(False)> _
    Public Function GetUIContainerForInspector( _
    ByVal inspector As Outlook.Inspector) As UserInterfaceContainer
        Dim uiContainer As UserInterfaceContainer
        uiContainer = Nothing

        For Each uic As UserInterfaceContainer In _items
            If (uic.Inspector Is inspector) Then
                uiContainer = uic
                Exit For
            End If
        Next

        Return uiContainer
    End Function

    ' 在给定检查器的情况下，返回匹配的任务窗格。
    ' 此方法由于其 Office 参数的缘故不符合 CLS。
    <CLSCompliant(False)> _
    Public Function GetTaskPaneForInspector( _
    ByVal inspector As Outlook.Inspector) As Office.Core.CustomTaskPane

        Dim taskpane As Office.Core.CustomTaskPane = Nothing

        For Each uic As UserInterfaceContainer In _items
            If (uic.Inspector Is inspector) Then
                taskpane = uic.TaskPane
                Exit For
            End If
        Next

        Return taskpane
    End Function

    ' 在给定检查器的情况下，返回匹配的功能区。
    ' 此方法由于其 Office 参数的缘故不符合 CLS。
    <CLSCompliant(False)> _
    Public Function GetRibbonForInspector( _
    ByVal inspector As Outlook.Inspector) As IRibbonConnector
        Dim ribbonConnector As IRibbonConnector
        ribbonConnector = Nothing

        For Each uic As UserInterfaceContainer In _items
            If (uic.Inspector Is inspector) Then
                ribbonConnector = uic.RibbonConnector
                Exit For
            End If
        Next

        Return ribbonConnector
    End Function

    ' 在给定 UserControl 的情况下，返回匹配的功能区。
    ' 此方法由于其返回类型的缘故不符合 CLS。
    <CLSCompliant(False)> _
    Public Function GetRibbonForUserControl( _
    ByVal userControl As UserControl) As IRibbonConnector
        Dim ribbonConnector As IRibbonConnector
        ribbonConnector = Nothing

        For Each uic As UserInterfaceContainer In _items
            If (uic.TaskPane.ContentControl Is userControl) Then
                ribbonConnector = uic.RibbonConnector
                Exit For
            End If
        Next

        Return ribbonConnector
    End Function

    ' 在给定 UserControl 的情况下，返回匹配的 UI 容器对象。
    Public Function GetUIContainerForUserControl( _
    ByVal userControl As UserControl) As UserInterfaceContainer

        Dim uiContainer As UserInterfaceContainer
        uiContainer = Nothing

        For Each uic As UserInterfaceContainer In _items
            If (uic.TaskPane.ContentControl Is userControl) Then
                uiContainer = uic
                Exit For
            End If
        Next

        Return uiContainer
    End Function

End Class
