﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此类仅扩展 MenuItem 类以支持 View 属性。
Class MenuItemView
    Inherits ToolStripMenuItem
    Public View As View
End Class
