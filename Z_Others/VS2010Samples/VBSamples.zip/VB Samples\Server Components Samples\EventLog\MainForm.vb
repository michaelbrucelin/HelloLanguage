﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
Public Class MainForm

    '' 在写入某一事件日志时，需要传递该日志
    '' 所在计算机的名称。此处使用 Environment 类的 MachineName 属性
    '' 确定本地计算机的名称。假定您具有
    '' 适当的权限，同时还可以轻松地写入
    '' 其他计算机上的事件日志。
    'Private machineName As String = Environment.MachineName
    'Private logType As String = ""
    'Private entryType As EventLogEntryType = EventLogEntryType.Error

    Private Sub btnWrite_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWrite.Click
        Dim frmWrite As New WriteForm()
        frmWrite.ShowDialog()
    End Sub

    Private Sub btnRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRead.Click
        Dim frmRead As New ReadForm()
        frmRead.ShowDialog()
    End Sub

    Private Sub btnCreateDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateDelete.Click
        Dim frmCreateDelete As New CreateDeleteForm()
        frmCreateDelete.ShowDialog()
    End Sub

    Private Sub exitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitToolStripMenuItem.Click
        Me.Close()
    End Sub
End Class