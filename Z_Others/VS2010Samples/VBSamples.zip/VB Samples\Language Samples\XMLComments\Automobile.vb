﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
''' <summary>
'''此类用于演示
'''Visual Basic 中可用的类成员范围，并演示代码编辑器如何生成 XML 注释。
''' </summary>
''' <remarks>此类的成员未实现，因为与该示例
'''无关。
''' </remarks>
Public Class Automobile

    ''' <summary>
    '''引擎有两个可用选项。
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum EngineOption
        Road = 1500
        Towing = 2200
    End Enum


    ''' <summary>
    '''使用工厂标准包创建 Automobile 的
    '''新实例。
    ''' </summary>
    ''' <remarks>此方法未实现。</remarks>
    Public Sub New()

    End Sub

    ''' <summary>
    '''使用客户选择的引擎选项创建 Automobile 的
    '''新实例。
    ''' </summary>
    ''' <param name="engineSize">可用引擎选项。</param>
    ''' <remarks>将此构造函数用于特殊的引擎包。</remarks>
    Public Sub New(ByVal engineSize As EngineOption)

    End Sub

    ''' <summary>
    '''Model 属性的私有变量。
    ''' </summary>
    ''' <remarks>将来可将此变量局限于几个选项中的一个。</remarks>
    Private modelValue As String

    ''' <summary>
    '''汽车型号的名称。
    ''' </summary>
    ''' <value>建议值为 Standard、Deluxe 和 Luxury。</value>
    ''' <remarks></remarks>
    Public Property Model() As String
        Get
            Return modelValue
        End Get
        Set(ByVal value As String)
            modelValue = value
        End Set
    End Property

    ''' <summary>
    '''如果客户在最初订购之后要求更换引擎，
    '''则调用此方法。
    ''' </summary>
    ''' <param name="engineSize">可用引擎选项。</param>
    ''' <remarks>只能在交付汽车之前
    '''调用此方法。</remarks>
    Public Sub Upgrade(ByVal engineSize As EngineOption)

    End Sub

    ''' <summary>
    '''最大牵引重量取决于型号和引擎。
    ''' </summary>
    ''' <returns>汽车可安全牵引的磅数。</returns>
    ''' <remarks>无。</remarks>
    Public Function CalculateMaxTowing() As Integer

    End Function

    ''' <summary>
    '''如果汽车可牵引指定的磅数，则返回 True。
    ''' </summary>
    ''' <param name="pounds">客户希望汽车能够牵引的磅数。</param>
    ''' <returns>如果汽车可牵引该重量，则为 True。</returns>
    ''' <remarks>无。</remarks>
    Public Function WillItTow(ByVal pounds As Integer) As Boolean

    End Function

    ''' <summary>
    '''当客户做出超过最大值的 50％ 的牵引请求 (WillItTwo) 时
    '''引发。
    ''' </summary>
    ''' <param name="sender">查询的汽车。</param>
    ''' <param name="e">EventArgs</param>
    ''' <remarks>无。</remarks>
    Public Event NeedsTuneUp(ByVal sender As Object, ByVal e As EventArgs)

    ''' <summary>
    '''转动轮胎的方法。
    ''' </summary>
    ''' <remarks>允许不同的商店使用不同的转动模式。</remarks>
    Public Delegate Sub RotateTires()


    ''' <summary>
    '''更换火花塞的方法。
    ''' </summary>
    ''' <param name="plugs">新火花塞的说明。</param>
    ''' <returns>如果更换成功则为 True。</returns>
    ''' <remarks>允许不同的商店使用不同的方法和火花塞。</remarks>
    Public Delegate Function ReplaceSparkPlugs(ByVal plugs As String) As Boolean


End Class
