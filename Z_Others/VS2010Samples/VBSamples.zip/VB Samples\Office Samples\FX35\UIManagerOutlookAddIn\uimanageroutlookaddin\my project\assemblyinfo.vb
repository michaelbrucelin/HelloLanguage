﻿'此代码和信息是“按原样”提供，并无任何形式
'(明确或暗示)的担保，包括但不限于
'适销性和/或适合特定目的
'的暗示担保。

'版权所有(C) Microsoft Corporation。保留所有权利。

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Runtime.CompilerServices
Imports System.Resources

<Assembly: AssemblyTitle("UiManagerOutlookAddIn")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft")> 
<Assembly: AssemblyProduct("UiManagerOutlookAddIn")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft 2007")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 
<Assembly: Guid("24514c00-ed2e-4195-b494-b8096a60a21f")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 

<Assembly: CLSCompliant(True)> 
<Assembly: NeutralResourcesLanguage("en-us")> 

