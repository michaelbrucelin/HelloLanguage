﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。

Imports Microsoft.SharePoint.Workflow
Imports System.Workflow.Activities

Public Class Workflow1
    Inherits SequentialWorkflowActivity

    Public workflowProperties As New SPWorkflowActivationProperties

    Public Sub New()
        MyBase.New()
        InitializeComponent()
    End Sub
    Public taskId1 As System.Guid = Nothing
    Public taskProperties As SPWorkflowTaskProperties = New Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties
    Public afterProperties As SPWorkflowTaskProperties = New Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties
    Public beforeProperties1 As SPWorkflowTaskProperties = New Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties
    Private taskCompleted As Boolean = False

    Private Sub createTask1_MethodInvoking(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '任务必须具有 guid
        taskId1 = Guid.NewGuid()
        With taskProperties
            '设置基本任务属性
            .PercentComplete = 0.0
            .AssignedTo = System.Threading.Thread.CurrentPrincipal.Identity.Name
            .TaskType = 0
            .DueDate = DateTime.Now.AddDays(7)
            .StartDate = DateTime.Now()
            .Title = "SharePoint Workflow Task"
        End With
    End Sub

    '当任务已更改为 100% 完成时，此过程评估结果为 False
    Private Sub notCompleted(ByVal sender As System.Object, ByVal e As System.Workflow.Activities.ConditionalEventArgs)
        '要完成任务则结果必须为 1.0
        e.Result = Not taskCompleted
    End Sub

    Private Sub onTaskChanged1_Invoked(ByVal sender As System.Object, ByVal e As System.Workflow.Activities.ExternalDataEventArgs)
        '更改后检查任务属性。
        '查找 1.0 以反映已完成的任务。
        If afterProperties.PercentComplete = 1.0 Then
            taskCompleted = True
        End If
    End Sub
End Class