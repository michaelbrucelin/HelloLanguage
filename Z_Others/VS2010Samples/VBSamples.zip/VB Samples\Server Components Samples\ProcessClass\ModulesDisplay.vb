﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
Public Class ModulesDisplay

    Private processIdValue As Integer

    Public Property ProcessID() As Integer
        Get
            Return processIdValue
        End Get
        Set(ByVal Value As Integer)
            processIdValue = Value
        End Set
    End Property

    Private Sub ModulesDisplay_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' 在 TaskManager 窗体中采用由 btnModules_Click 事件过程生成的
        ' 模块的字符串，并在 RichTextBox 中向用户显示。
        Dim ProcessInfo As Process = _
            Process.GetProcessById(ProcessID)
        Dim modl As ProcessModuleCollection = ProcessInfo.Modules
        Dim strMod As New System.Text.StringBuilder()
        For Each proMod As ProcessModule In modl
            strMod.Append("Module Name: " + proMod.ModuleName + vbCrLf)
        Next proMod
        rchText.Text = strMod.ToString
    End Sub



End Class