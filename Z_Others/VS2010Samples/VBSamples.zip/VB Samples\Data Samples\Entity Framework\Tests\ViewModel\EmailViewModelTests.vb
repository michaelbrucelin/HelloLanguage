﻿' 版权所有(C) Microsoft Corporation。保留所有权利。


Imports Microsoft.VisualBasic
Imports System
Imports System.Diagnostics.CodeAnalysis
Imports EmployeeTracker.Model
Imports EmployeeTracker.ViewModel
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Tests

Namespace Tests.ViewModel

    ''' <summary>
    ''' 针对 EmailViewModel 的单元测试
    ''' </summary>
    <TestClass>
    Public Class EmailViewModelTests
        ''' <summary>
        ''' 验证用于 ViewModel 的 getter 和 setter 是否会影响基础数据并通知更改
        ''' </summary>
        <TestMethod>
        Public Sub PropertyGetAndSet()
            ' 测试初始属性出现在 ViewModel 中
            Dim em As Email = New Email With {.Address = "EMAIL"}
            Dim vm As New EmailViewModel(em)
            Assert.AreEqual(em, vm.Model, "Bound object property did not return object from model.")
            Assert.AreEqual(em.ValidUsageValues, vm.ValidUsageValues, "ValidUsageValues property did not return value from model.")
            Assert.AreEqual("EMAIL", vm.Address, "Address property did not return value from model.")

            ' 测试更改属性将更新模型并引发 PropertyChanged
            Dim lastProperty As String
            AddHandler vm.PropertyChanged, Sub(sender, e) lastProperty = e.PropertyName

            lastProperty = Nothing
            vm.Address = "NEW_EMAIL"
            Assert.AreEqual("Address", lastProperty, "Setting Address property did not raise correct PropertyChanged event.")
            Assert.AreEqual("NEW_EMAIL", em.Address, "Setting Address property did not update model.")
        End Sub

        ''' <summary>
        ''' 验证 getter 是否反映模型中的更改
        ''' </summary>
        <TestMethod>
        Public Sub ModelChangesFlowToProperties()
            ' 测试 ViewModel 会返回模型中的当前值
            Dim em As Email = New Email With {.Address = "EMAIL"}
            Dim vm As New EmailViewModel(em)

            em.Address = "NEW_EMAIL"
            Assert.AreEqual("NEW_EMAIL", vm.Address, "Address property is not fetching the value from the model.")
        End Sub

        ''' <summary>
        ''' 验证对于 null 无效的情况是否引发 NullArgumentExceptions
        ''' </summary>
        <TestMethod>
        Public Sub CheckNullArgumentExceptions()
            Dim ctor As Action = Sub()
                                     Dim x = New EmailViewModel(Nothing)
                                 End Sub

            Utilities.CheckNullArgumentException(ctor, "detail", "ctor")
        End Sub
    End Class
End Namespace
