﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。

Imports System
Imports System.Data
Imports System.Drawing
Imports System.Windows.Forms
Imports System.IO
Imports System.ComponentModel
Imports System.Globalization
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Sheet1

    ''' <summary>
    ''' 将在此处创建数据透视表。
    ''' </summary>        
    Private Const pivotTableAddress As String = "$B$22"

    ''' <summary>
    ''' Sales 列表的数据源。此视图基于 Globals.DataSet 的 Sales 表，
    ''' 是为显示一天的数据而筛选出来的。
    ''' </summary>
    Private dayView As OperationsData.OperationsView

    ''' <summary>
    ''' 包含销售额统计信息的数据透视表。
    ''' </summary>
    Private pivotTable As Excel.PivotTable

    ''' <summary>
    ''' 如果当前选定的日期是最后一个有数据的日期，那么，
    ''' 还将显示另外两列，即“Estimated Inventory”和“Recommendation”，
    ''' 并且 columnsAdded 设置为 true；否则它为 false。
    ''' </summary>
    Private columnsAdded As Boolean = False

    Private Sub Sheet1_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup

        Try
            Me.Sheet1_TitleLabel.Value2 = My.Resources.Sheet1Title
            Me.Name = My.Resources.Sheet1Name

            Me.newDateButton.Text = My.Resources.AddNewDateButton
            Me.saveButton.Text = My.Resources.SaveDataButton

            Me.dayView = Globals.DataSet.CreateView()

            If Globals.DataSet.Sales.Count <> 0 Then
                Me.DateSelector.MinDate = Globals.DataSet.MinDate
                Me.DateSelector.MaxDate = Globals.DataSet.MaxDate
            End If


            Using textFile As New TextFileGenerator(Globals.DataSet.Sales)
                Me.pivotTable = CreatePivotTable(textFile.FullPath)
            End Using

            AddHandler Globals.DataSet.Sales.SalesRowChanged, AddressOf Me.ViewInventoryChange

            SetLocalizedColumnNames()

            Dim smartPaneControl As New UnscheduledOrderControl()
            smartPaneControl.Dock = DockStyle.Fill
            smartPaneControl.View = Me.dayView

            Globals.ThisWorkbook.ActionsPane.Controls.Add(smartPaneControl)

            Me.Activate()

        Catch ex As Exception
            Debug.WriteLine(ex.ToString())
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Sheet1_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown

    End Sub


    ''' <summary>
    ''' 向工作表的列表对象中添加“Estimated Inventory”
    ''' 和“Recommendation”两列。
    ''' </summary>
    Private Sub AddColumns()
        If (Not Me.columnsAdded) Then
            dayView.BindToProtectedList(Me.DayInventory, "Flavor", "Inventory", "Sold", "Profit", "Estimated Inventory", "Recommendation")
            SetLocalizedColumnNames()
            Me.columnsAdded = True
        End If
    End Sub

    ''' <summary>
    ''' 从工作表的列表对象中移除“Estimated Inventory”
    ''' 和“Recommendation”两列。
    ''' </summary>
    Private Sub RemoveColumns()
        If (columnsAdded) Then
            dayView.BindToProtectedList(Me.DayInventory, "Flavor", "Inventory", "Sold", "Profit")
            SetLocalizedColumnNames()
            Me.columnsAdded = False
        End If
    End Sub

    ''' <summary>
    ''' 创建一个数据透视表，其中包含的数据来自用制表符分隔的文本文件。
    ''' </summary>
    ''' <param name="filePath">文本文件所在位置。</param>
    ''' <returns>已创建的数据透视表。</returns>
    Private Function CreatePivotTable(ByVal filePath As String) As Excel.PivotTable
        ' 如果该表已存在，
        ' 则返回现有的表。
        Dim tableName As String = My.Resources.AveragesPivotTableName
        Dim tables As Excel.PivotTables = CType(Me.PivotTables, Excel.PivotTables)
        Dim savedWidths As New System.Collections.Generic.Queue(Of Double)()

        If tables IsNot Nothing Then
            Dim count As Integer = tables.Count

            For i As Integer = 1 To count
                Dim table As Excel.PivotTable = tables.Item(i)
                If table.Name = tableName Then
                    Return table
                End If
            Next
        End If

        Try
            ' AddField 将调整列的大小。
            ' 保存列宽，以便在添加数据透视字段之后还原
            For Each column As Excel.Range In DayInventory.HeaderRowRange.Cells
                savedWidths.Enqueue(CType(column.ColumnWidth, Double))
            Next

            ' 创建数据透视表需要关闭保护功能。
            Globals.ThisWorkbook.MakeReadWrite()

            Dim table As Excel.PivotTable = Globals.ThisWorkbook.CreateSalesPivotTable(Me.Range(pivotTableAddress, System.Type.Missing), filePath)

            ' 在数据透视表中，添加所需的 
            ' 行和列。
            table.AddFields("Flavor")

            Dim soldField As Excel.PivotField = table.AddDataField(table.PivotFields("Sold"), My.Resources.AverageSold, Excel.XlConsolidationFunction.xlAverage)

            ' 在数据透视表中设置所需数据的视图。
            ' 格式“0.0”- 一个小数位。
            soldField.NumberFormat = "0.0"

            Dim profitField As Excel.PivotField = table.AddDataField(table.PivotFields("Profit"), My.Resources.AverageProfit, Excel.XlConsolidationFunction.xlAverage)

            ' 在数据透视表中设置所需数据的视图。
            ' 格式“0.00”- 两个小数位。
            profitField.NumberFormat = "0.00"

            ' 隐藏创建数据透视表时添加的两个浮动栏。
            Globals.ThisWorkbook.ShowPivotTableFieldList = False
            Application.CommandBars("PivotTable").Visible = False

            Return table
        Finally
            ' AddField 将调整列的大小。还原列宽。
            For Each column As Excel.Range In DayInventory.HeaderRowRange.Cells
                column.ColumnWidth = savedWidths.Dequeue()
            Next

            Globals.ThisWorkbook.MakeReadOnly()
        End Try

    End Function


    Private Sub ViewInventoryChange(ByVal sender As Object, ByVal e As OperationsData.SalesRowChangeEvent)
        If e.Action = DataRowAction.Change Then
            Globals.ThisWorkbook.UpdateSalesPivotTable(Me.pivotTable)
        End If
    End Sub

    ''' <summary>
    ''' 将列表对象的列标题设置为资源中的值。
    ''' </summary>
    Private Sub SetLocalizedColumnNames()
        Dim localizedInventoryColumns() As String = { _
            My.Resources.IceCreamHeader, _
            My.Resources.EodInventoryHeader, _
            My.Resources.UnitsSoldHeader, _
            My.Resources.NetGainHeader, _
            My.Resources.EstimatedInventoryHeader, _
            My.Resources.RecommendationHeader _
        }

        Try
            Globals.ThisWorkbook.MakeReadWrite()
            Me.DayInventory.HeaderRowRange.Value2 = localizedInventoryColumns
        Finally
            Globals.ThisWorkbook.MakeReadOnly()
        End Try
    End Sub

    ''' <summary>
    ''' DateTimePicker 的 ValueChanged 事件处理程序。
    ''' 更改 dateView 以显示选定日期。
    ''' </summary>
    ''' <param name="sender">事件的发送者。</param>
    ''' <param name="e">事件参数。</param>
    Private Sub dateSelector_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DateSelector.ValueChanged
        Dim control As DateTimePicker = CType(sender, DateTimePicker)

        dayView.CurrentDate = control.Value

        Dim lastDay As DateTime = control.MaxDate

        If (control.Value = lastDay) Then
            AddColumns()
        Else
            RemoveColumns()
        End If
    End Sub

    Private Sub newDateButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles newDateButton.Click
        Try
            If (Not Globals.DataSet.IsLastDayComplete()) Then
                MessageBox.Show(Globals.ThisWorkbook.IncompleteDataMessage)
                Return
            End If

            Dim nextDate As DateTime = Globals.DataSet.MaxDate.AddDays(1)

            Dim row As OperationsBaseData.PricingRow
            For Each row In Globals.DataSet.Pricing
                Dim NewRow As OperationsBaseData.SalesRow = CType(Me.dayView.Table.NewRow(), OperationsBaseData.SalesRow)
                NewRow.Flavor = row.Flavor
                NewRow._Date = nextDate

                Me.dayView.Table.AddSalesRow(NewRow)
            Next

            Me.DateSelector.MaxDate = nextDate
            Me.DateSelector.Value = nextDate
        Catch ex As Exception
            Debug.WriteLine(ex.ToString())
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub saveButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles saveButton.Click
        Globals.DataSet.Save()
    End Sub

End Class
