﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
' 此代码和信息“按原样”提供，不提供任何形式的
' 明示或暗示担保，包括但不限于
' 适销性和/或适合特定目的
' 的暗示担保。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。

' 有关程序集的常规信息通过下列特性集
' 控制。更改这些特性值可修改
' 与程序集关联的信息。

' 检查程序集特性的值

<Assembly: AssemblyTitle("SequentialWorkflow")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft")> 
<Assembly: AssemblyProduct("SequentialWorkflow")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft 2009")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
'如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
<Assembly: Guid("0c672173-2d62-4512-b569-7b38320fdd81")> 
<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 