﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports Microsoft.Office.Tools.Excel

' 有关程序集的常规信息通过下列特性集
' 控制。更改这些特性值可修改
' 与程序集关联的信息。

' 检查程序集特性的值

<Assembly: AssemblyTitle("RibbonControlsExcelWorkbook")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft")> 
<Assembly: AssemblyProduct("RibbonControlsExcelWorkbook")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft 2007")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
<Assembly: Guid("17f5454e-00f6-430e-b4b5-35aa0125117e")> 

' 程序集的版本信息由下列四个值组成:
'
'      主版本
'      次版本
'      内部版本号
'      修订号
'
' 可以指定所有这些值，也可以使用“内部版本号”和“修订号”的默认值，
' 方法是按如下所示使用“*”:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 

' ExcelLocale1033 特性用于控制传递给 Excel 对象模型的区域设置。
' 将 ExcelLocale1033 设置为 true 会使 Excel 对象模型在
' 所有区域设置下采取同一行为，该行为与 Visual Basic for Applications 
' 的行为相符。将 ExcelLocale1033 设置为 false 会使 Excel 对象模型
' 的行为随用户的区域设置不同而不同，该行为 
' 与 Visual Studio Tools for Office 版本 2003 的行为相符。这会导致 
' 区分区域设置的信息(如公式名和日期格式)中出现意外结果。

<Assembly: ExcelLocale1033(True)>
