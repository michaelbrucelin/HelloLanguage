﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
Public Class EmployeeForm
    Private db As NorthwindDataContext
    Public Sub New()

        ' 此调用是 Windows 窗体设计器所必需的。
        InitializeComponent()

        ' 请在 InitializeComponent() 调用后添加初始化。
        db = New NorthwindDataContext
        Dim employeeQuery = From employee In db.Employees _
                                Order By employee.LastName _
                                Select employee
        Dim managerQuery = From manager In db.Employees _
                            Order By manager.LastName _
                            Select manager
        'ToBindingList 方法可将查询转换成支持 IBindingList 的结构。
        '必须使用 Table<T> 才能转换为绑定列表，以便正确跟踪
        '实体的添加和删除。
        employeeBindingSource.DataSource = employeeQuery
        managerBindingSource.DataSource = managerQuery.ToList()
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click, btnSave.Click
        Me.Validate()
        db.SubmitChanges()
    End Sub

    Private Sub employeeDataGridView_CellParsing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellParsingEventArgs) Handles employeeDataGridView.CellParsing
        Dim s As String = e.Value.ToString()

        '需要使用 OfType，因为 employeeBindingSource 可以返回多个类型对象实例。
        Dim emp As Employee = (From employee In managerBindingSource.OfType(Of Employee)() _
                              Where employee.ToString() = s _
                              Select employee).FirstOrDefault()

        e.Value = emp
        e.ParsingApplied = True
    End Sub

    Private Sub btnLaunchMasterDetail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLaunchMasterDetail.Click
        Dim Form As WinFormsDataBinding.EmployeeManagerGrids = New EmployeeManagerGrids()
        Form.Visible = True
    End Sub

End Class
