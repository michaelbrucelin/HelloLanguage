﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。


Imports Microsoft.VisualBasic
Imports System.ComponentModel

Namespace EmployeeTracker.ViewModel.Helpers

    ''' <summary>
    ''' 用于合并所有 ViewModel 的常见功能的抽象基类
    ''' </summary>
    Public MustInherit Class ViewModelBase
        Implements INotifyPropertyChanged
        ''' <summary>
        ''' 当此对象的属性有新值时引发
        ''' </summary>
        Public Event PropertyChanged As PropertyChangedEventHandler Implements INotifyPropertyChanged.PropertyChanged

        ''' <summary>
        ''' 引发此 ViewModels 的 PropertyChanged 事件
        ''' </summary>
        ''' <param name="propertyName">具有新值的属性的名称</param>
        Protected Sub OnPropertyChanged(ByVal propertyName As String)
            Me.OnPropertyChanged(New PropertyChangedEventArgs(propertyName))
        End Sub

        ''' <summary>
        ''' 引发此 ViewModels 的 PropertyChanged 事件
        ''' </summary>
        ''' <param name="e">详细描述更改的参数</param>
        Protected Overridable Sub OnPropertyChanged(ByVal e As PropertyChangedEventArgs)
            Dim handler = Me.PropertyChangedEvent
            If handler IsNot Nothing Then
                handler(Me, e)
            End If
        End Sub
    End Class
End Namespace
