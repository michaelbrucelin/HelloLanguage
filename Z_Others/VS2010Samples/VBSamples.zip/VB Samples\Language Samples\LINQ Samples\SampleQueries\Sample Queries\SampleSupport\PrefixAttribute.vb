﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
Imports System

Namespace SampleSupport
    <AttributeUsage((AttributeTargets.Method Or AttributeTargets.Class), AllowMultiple:=False)> _
    Public NotInheritable Class PrefixAttribute
        Inherits Attribute
        ' 方法
        Public Sub New(ByVal prefix As String)
            _prefix = prefix

        End Sub


        ' 属性
        Public ReadOnly Property Prefix As String
            Get
                Return _prefix
            End Get
        End Property


        ' 字段
        Private ReadOnly _prefix As String
    End Class
End Namespace

