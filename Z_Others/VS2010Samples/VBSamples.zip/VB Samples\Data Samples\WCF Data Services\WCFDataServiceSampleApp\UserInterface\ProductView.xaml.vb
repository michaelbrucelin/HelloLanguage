﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Imaging
Imports System.Windows.Shapes
Imports AdventureWorksService
Imports UserInterface.Gateways

Namespace UserInterface
	''' <summary>
	''' ProductView.xaml 的交互逻辑
	''' </summary>
	Partial Public Class ProductView
		Inherits Window


		Private gateway As ProductGateway


	''' <summary>
		''' 启动时启动输入窗体
		''' </summary>
		Public Sub New(ByVal gateway As ProductGateway)
			InitializeComponent()
			Me.gateway = gateway
		End Sub

		''' <summary>
		''' 如果为 true，则 ProductView 窗口将用于创建/添加新产品。
		''' 如果为 false，则 ProductView 窗口将用于编辑现有产品。
		''' </summary>
		Private _FormCreateMode As Boolean = True

		Private Property FormCreateMode() As Boolean
			Get
				Return _FormCreateMode
			End Get
			Set(ByVal value As Boolean)
				_FormCreateMode = value
			End Set
		End Property

		''' <summary>
		''' 所编辑或创建的产品实例。
		''' </summary>
		Private Property product() As Product


		Public Sub UpdateProduct(ByVal product As Product)
			Me.product = gateway.GetProducts(product.Name, product.ProductCategory)(0)
			FormCreateMode = False
			Me.Title = "Edit " & product.Name
		End Sub


		Private Sub BtnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
			Me.Close()
		End Sub

		Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
			BindCategories()
			If FormCreateMode Then
				product = New Product()
			End If
			BindProduct()
		End Sub

		''' <summary>
		''' 将所更新/创建的产品实例的属性绑定到对应的文本框。
		''' </summary>
		Private Sub BindProduct()
			txtProductNumber.DataContext = product
			txtName.DataContext = product
			txtListPrice.DataContext = product
			txtColor.DataContext = product
			CategoryComboBoxProductDetail.DataContext = product
			txtModifiedDate.DataContext = product
			txtSellStartDate.DataContext = product
			txtStandardCost.DataContext = product
		End Sub

		''' <summary>
		''' 查询类别列表并绑定到组合框
		''' </summary>
		Private Sub BindCategories()
			CategoryComboBoxProductDetail.ItemsSource = gateway.GetCategories()
			CategoryComboBoxProductDetail.SelectedIndex = 0
		End Sub


		Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
			If FormCreateMode Then
				product.ProductCategory = CType(CategoryComboBoxProductDetail.SelectedItem, ProductCategory)
				gateway.AddProduct(product)
			Else
				product.ProductCategory = CType(CategoryComboBoxProductDetail.SelectedItem, ProductCategory)
				gateway.UpdateProduct(product)
			End If
			Me.Close()
		End Sub
	End Class
End Namespace
