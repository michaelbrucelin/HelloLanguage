﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。

Imports Microsoft.VisualStudio.SharePoint
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel

Namespace Contoso.SharePointProjectItems.CustomAction

    Partial Friend Class CustomActionProvider

        Private Sub ProjectItemPropertiesRequested(ByVal Sender As Object, _
            ByVal e As SharePointProjectItemPropertiesRequestedEventArgs)

            Dim properties As CustomActionProperties = Nothing

            ' 如果属性对象已存在，则从项目项的批注中获取它。
            If False = e.ProjectItem.Annotations.TryGetValue(properties) Then
                ' 否则，创建一个新的属性对象并将其添加到批注。
                properties = New CustomActionProperties(e.ProjectItem)
                e.ProjectItem.Annotations.Add(properties)
            End If
            e.PropertySources.Add(properties)
        End Sub
    End Class

    Friend Class CustomActionProperties

        Private projectItem As ISharePointProjectItem
        Private Const testPropertyId As String = "Contoso.CustomActionTestProperty"
        Private Const propertyDefaultValue As String = "This is a test value."

        Friend Sub New(ByVal projectItem As ISharePointProjectItem)
            Me.projectItem = projectItem
        End Sub

        ' 获取或设置一个简单的字符串属性。属性值存储在项目项的 ExtensionData 属性中。
        ' ExtensionData 属性中的数据在项目关闭后保留。
        <DisplayName("Custom Action Property")> _
        <DescriptionAttribute("This is a test property for the Contoso Custom Action project item.")> _
        <DefaultValue(propertyDefaultValue)> _
        Public Property TestProperty As String
            Get
                Dim propertyValue As String = Nothing

                ' 获取当前属性值(如果已存在)；否则返回默认值。
                If False = projectItem.ExtensionData.TryGetValue(testPropertyId, propertyValue) Then
                    propertyValue = propertyDefaultValue
                End If
                Return propertyValue
            End Get
            Set(ByVal value As String)
                If value <> propertyDefaultValue Then
                    projectItem.ExtensionData(testPropertyId) = value
                Else
                    ' 不保存默认值。
                    projectItem.ExtensionData.Remove(testPropertyId)
                End If
            End Set
        End Property
    End Class
End Namespace
