﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。

Imports System
Imports System.Data
Imports System.Drawing
Imports System.Windows.Forms
Imports Excel = Microsoft.Office.Interop.Excel

''' <summary>
''' 此工作表显示某个 flavorField 的冰淇淋的历史销售额数据。
''' </summary>
Public Class Sheet2
    ''' <summary>
    ''' 该数据视图基于 Sales 表生成并且按 flavorField 进行筛选。
    ''' </summary>
    Private view As OperationsData.OperationsView

    ''' <summary>
    ''' 已显示其历史记录的 flavorField。
    ''' </summary>
    Private flavorField As String = Nothing

    ''' <summary>
    ''' flavorField 字段的访问器和转变器。
    ''' 修改属性时，也会对视图进行相应的更改。
    ''' </summary>
    ''' <value>当前的 flavorField。</value>
    Public Property Flavor() As String
        Get
            Return flavorField
        End Get
        Set(ByVal Value As String)
            flavorField = Value

            RaiseEvent FlavorChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("Flavor"))

            If view IsNot Nothing Then
                view.Flavor = flavorField
            End If
        End Set
    End Property

    ''' <summary>
    ''' 当 Flavor 发生更改时，将引发事件。使用 Flavor 属性
    ''' 进行数据绑定时，PropertyManager 侦听此事件。
    ''' </summary>
    Public Event FlavorChanged As EventHandler


    Private Sub Sheet2_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup

        Me.Sheet2_TitleLabel.Value2 = My.Resources.Sheet2Title
        Me.Name = My.Resources.Sheet2Name
        Me.IceCreamLabel.Value2 = My.Resources.IceCreamHeader

        Me.Chart_1.ChartTitle.Text = My.Resources.ProfitHeader
        CType(Me.Chart_1.Axes(Excel.XlAxisType.xlValue, Excel.XlAxisGroup.xlPrimary), Excel.Axis).AxisTitle.Text = My.Resources.ProfitHeader
        CType(Me.Chart_1.Axes(Excel.XlAxisType.xlCategory, Excel.XlAxisGroup.xlPrimary), Excel.Axis).AxisTitle.Text = My.Resources.DateHeader

        Me.view = Globals.DataSet.CreateView()

        If Me.flavorField IsNot Nothing Then
            view.Flavor = Me.flavorField
        Else
            Me.Flavor = CType(view(0).Row("Flavor"), String)
        End If

        Me.History.SetDataBinding(view, "", "Date", "Inventory", "Sold", "Profit")
        Me.History.ListColumns(1).Name = My.Resources.DateHeader
        Me.History.ListColumns(2).Name = My.Resources.InventoryHeader
        Me.History.ListColumns(3).Name = My.Resources.SoldHeader
        Me.History.ListColumns(4).Name = My.Resources.ProfitHeader

        Me.FlavorNamedRange.DataBindings.Add("Value2", Me, "Flavor")
    End Sub

    Private Sub Sheet2_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown

    End Sub

End Class
