﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
Module Pipes

    Sub Main()
        ' 这是实际管道包含的内容，ICollection
        Dim pipe As New MyPipe(Of System.Collections.ICollection)

        ' 当授予对管道的写访问权限时，我们可能要告诉写入者
        ' 他们必须提供 IList
        Dim r As IWritable(Of IList) = pipe
        writer(r)

        ' 但是，当授予对管道的读访问权限时，我们可能要告诉读取者
        ' 他们只可以假定管道内容为 IEnumerable
        Dim w As IReadable(Of IEnumerable) = pipe
        reader(w)
    End Sub


    Sub writer(ByVal pipe As IWritable(Of IList))
        Dim a As String() = {"hello", "world"}
        pipe.Push(a)
    End Sub

    Sub reader(ByVal pipe As IReadable(Of IEnumerable))
        Dim a = pipe.Pop()
        For Each s In a
            Console.WriteLine(s)
        Next
    End Sub

End Module
