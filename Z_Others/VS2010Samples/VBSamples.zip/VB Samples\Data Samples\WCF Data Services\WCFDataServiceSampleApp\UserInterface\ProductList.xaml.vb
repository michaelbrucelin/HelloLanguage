﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Imaging
Imports System.Windows.Navigation
Imports System.Windows.Shapes
Imports UserInterface.Gateways
Imports AdventureWorksService


Namespace UserInterface
	''' <summary>
	''' ProductList.xaml 的交互逻辑
	''' </summary>
	Partial Public Class ProductList
		Inherits Window

		Private gateway As ProductGateway


	''' <summary>
		''' 启动时启动输入窗体
		''' </summary>
		Public Sub New()
			InitializeComponent()
			gateway = New ProductGateway()
			AddHandler ProductsListView.MouseDoubleClick, AddressOf ProductsListView_MouseDoubleClick
		End Sub

	''' <summary>
		''' 将 gateway.GetCategories() 的结果绑定到窗体顶部的“产品类别”组合框。
		''' </summary>
		Private Sub BindCategories()
			CategoryComboBox.ItemsSource = gateway.GetCategories()
			CategoryComboBox.SelectedIndex = 0
		End Sub

	''' <summary>
		''' 将 gateway.GetProducts(string ProductName, ProductCategory p) 的结果绑定到 ListView 控件。
		''' </summary>
		Private Sub BindProducts()
			If CategoryComboBox.SelectedIndex > -1 Then
				ProductsListView.ItemsSource = gateway.GetProducts(NameTextBox.Text, TryCast(CategoryComboBox.SelectedItem, ProductCategory))
			End If
		End Sub

		Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
			BindCategories()
		End Sub

		Private Sub ProductsListView_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Input.MouseButtonEventArgs)
			Dim p As Product = TryCast(ProductsListView.SelectedItem, Product)
			Dim window As New ProductView(gateway)
			AddHandler window.Closed, AddressOf window_Closed
			window.UpdateProduct(p)
			window.Show()
		End Sub

	''' <summary>
		''' 单击“搜索”按钮时调用 BindProducts()。
		''' </summary>
		Private Sub btnSearch_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
			BindProducts()
		End Sub

		Private Sub btnNewProduct_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
			Dim window As New ProductView(gateway)
			AddHandler window.Closed, AddressOf window_Closed
			window.Show()
		End Sub

	''' <summary>
		''' 调用 gateway.DeleteProduct() 以开始删除所选的产品。如果无法删除产品，则 gateway.DeleteProduct 
	''' 不会返回 null，并且通过 MessageBox 向用户显示响应消息。
		''' </summary>
		Private Sub btnDeleteProduct_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
			Dim p As Product = TryCast(ProductsListView.SelectedItem, Product)
			If p IsNot Nothing Then
				Dim returned As String = gateway.DeleteProduct(p)
				If returned IsNot Nothing Then
					MessageBox.Show(returned)
				End If
				BindProducts()
			End If
		End Sub

	''' <summary>
		''' 选择新类别时刷新列表
		''' </summary>
		Private Sub CategoryComboBox_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
			BindProducts()
		End Sub

		Private Sub window_Closed(ByVal sender As Object, ByVal e As EventArgs)
			BindCategories()
		End Sub


	End Class
End Namespace
