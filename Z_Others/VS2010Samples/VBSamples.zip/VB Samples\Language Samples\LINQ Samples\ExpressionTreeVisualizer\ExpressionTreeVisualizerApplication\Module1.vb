﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
Imports Microsoft.VisualStudio.DebuggerVisualizers
Imports System.Linq.Expressions

Module Module1

    ' 可在调试环境中用 Expression Tree Visualizer 查看表达式。要使用
    ' 该可视化工具，必须将由 ExpressionTreeVisualizer 项目生成的 dll 复制到
    ' \我的文档\Visual Studio 2008\Visualizers 中。通过此控制台程序，不复制该 DLL 就能
    ' 在 Visual Studio 以外承载该可视化工具。
    Sub Main()
        Dim introduction = "The Visualizer may be hidden behind a window. Try the GuiHost."
        Console.WriteLine(introduction)
        Dim expr As Expression(Of Func(Of Integer, Boolean)) = Function(x) x = 10
        Dim host = New VisualizerDevelopmentHost(expr, _
                    GetType(ExpressionTreeVisualizer), _
                    GetType(ExpressionTreeVisualizerObjectSource))
        host.ShowVisualizer()
    End Sub

End Module
