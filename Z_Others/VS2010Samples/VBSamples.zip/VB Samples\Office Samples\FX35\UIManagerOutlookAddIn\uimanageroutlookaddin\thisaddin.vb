﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。


Imports System
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports Microsoft.VisualStudio.Tools.Applications.Runtime
Imports Outlook = Microsoft.Office.Interop.Outlook
Imports System.Collections
Imports System.Collections.Generic
Imports Office = Microsoft.Office
Imports UiManagerOutlookAddIn.AddinUtilities

<CLSCompliant(False)> _
Public Class ThisAddIn

    Private Sub ThisAddIn_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) _
    Handles Me.Shutdown
    End Sub

    Friend _taskPaneConnector As TaskPaneConnector
    Friend _ribbonConnector As RibbonConnector
    Private _formRegionConnector As FormRegionConnector
    Private _inspectors As Outlook.Inspectors
    Private _controlProgId As String = "UiManager.SimpleControl"
    Private _controlTitle As String = "SimpleControl"
    Friend _uiElements As UserInterfaceElements

    ' 重写 RequestService，以便为所实现的每个
    ' 新扩展性接口返回一个合适的对象。
    Protected Overrides Function RequestService( _
    ByVal serviceGuid As Guid) As Object
        If (serviceGuid = GetType(Office.Core.IRibbonExtensibility).GUID) Then
            If (_ribbonConnector Is Nothing) Then
                _ribbonConnector = New RibbonConnector()
            End If
            Return _ribbonConnector
        ElseIf (serviceGuid = GetType(Office.Core.ICustomTaskPaneConsumer).GUID) Then
            If (_taskPaneConnector Is Nothing) Then
                _taskPaneConnector = New TaskPaneConnector()
            End If
            Return _taskPaneConnector
        ElseIf (serviceGuid = GetType(Outlook.FormRegionStartup).GUID) Then
            If (_formRegionConnector Is Nothing) Then
                _formRegionConnector = New FormRegionConnector()
            End If
            Return _formRegionConnector
        End If

        Return MyBase.RequestService(serviceGuid)
    End Function

    Private Sub ThisAddIn_Startup(ByVal sender As Object, ByVal e As System.EventArgs) _
    Handles Me.Startup

        System.Windows.Forms.Application.EnableVisualStyles()

        Try
            ' 初始化 UI 元素集合并挂钩 NewInspector 事件，
            ' 这样就可以在创建每个检查器的同时将其添加到
            ' 集合中。
            _uiElements = New UserInterfaceElements()
            _inspectors = Me.Application.Inspectors
            AddHandler _inspectors.NewInspector, AddressOf inspectors_NewInspector
        Catch ex As COMException
            System.Diagnostics.Debug.WriteLine(ex.ToString())
        End Try

    End Sub

    ' 当打开一个新的检查器时，请创建一个任务窗格并将其
    ' 附加到此检查器。
    Sub inspectors_NewInspector(ByVal Inspector As Outlook.Inspector)
        CreateTaskPane(Inspector)
    End Sub


    ' 析出此行为的因子并传入一个公共方法，
    ' 以便可以独立于 NewInspector 事件调用此行为。
    ' 这样做的目的是允许使用以下争用条件: 可以在挂钩
    ' NewInspector 事件之前进行功能区
    ' 回调。
    Public Function CreateTaskPane( _
    ByVal inspector As Outlook.Inspector) As Office.Core.CustomTaskPane

        Dim taskpane As Office.Core.CustomTaskPane = Nothing

        Try
            If (Not _taskPaneConnector._ctpFactory Is Nothing) Then
                ' 创建一个新的任务窗格，并设置其宽度以符合
                ' SimpleControl 宽度。
                taskpane = _taskPaneConnector._ctpFactory.CreateCTP( _
                    _controlProgId, _controlTitle, inspector)
                taskpane.Width = 230

                ' 将任务窗格映射到检查器并将其缓存在
                ' 集合中。
                _uiElements.Add(New UserInterfaceContainer( _
                    inspector, taskpane, _ribbonConnector))
            End If

        Catch ex As COMException
            System.Diagnostics.Debug.WriteLine(ex.ToString())
        End Try

        Return taskpane

    End Function

End Class
