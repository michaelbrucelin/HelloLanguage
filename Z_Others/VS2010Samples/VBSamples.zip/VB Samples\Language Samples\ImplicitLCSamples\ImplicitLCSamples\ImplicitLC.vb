﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
Imports System.Reflection
Imports System.Runtime.CompilerServices

Module ImplicitLC

    Dim eol As String = vbCrLf

    ' 此模块中的示例利用了新的隐式行
    ' 继续符功能。将此处的代码与 ExplicitLC.vb 中的代码进行比较，
    ' 后者使用了显示的行继续符。
    Sub MethodQuery()
        Dim NameList = From method In _
                        (From type In Assembly.GetExecutingAssembly.GetTypes(),
                              method2 In type.GetMembers()
                         Where method2.MemberType = MemberTypes.Method AndAlso
                               CType(method2, MethodInfo).IsStatic
                         Select Item = CType(method2, MethodInfo)
                         Order By Item.Name)
                       Select method.Name
                       Distinct

        Form1.ResultsTextBox.Text &= vbCrLf & "Method Query: " & vbCrLf

        For Each m In NameList
            Form1.ResultsTextBox.Text &=
                                         "  " & m & vbCrLf
        Next

    End Sub

    Sub CustomerQuery()

        Dim customerList = Customer.GetCustomerList

        Dim selectedCompanies = From cust In customerList
                                Where cust.Name.StartsWith("C") And
                                      cust.CustomerID > 30000 And
                                      cust.City <> "Los Angeles"
                                Select cust.CustomerID, cust.Name,
                                       cust.State()

        Form1.ResultsTextBox.Text &= vbCrLf & "Customer Query: " & vbCrLf
        For Each selectedCo In selectedCompanies
            Form1.ResultsTextBox.Text &=
                                        "  " & selectedCo.Name & vbCrLf
        Next

    End Sub

    Sub MiscellaneousExamples(
        ByVal parameter1 As Integer,
        ByVal parameter2 As String,
        ByVal parameter3 As String
        )
        Form1.ResultsTextBox.Text &=
                vbCrLf & "Miscellaneous Examples:" & vbCrLf

        Dim str As String = "Testing PrintIndented extension method."
        str.PrintIndented()
        eol.PrintIndented()

        ' If...Then...Else
        If (parameter1 = 0) Or
           (parameter1 < 0) Then
            parameter2.PrintIndented()
        Else
            parameter3.PrintIndented()
        End If
        eol.PrintIndented()

        ' 对象初始值设定项
        Dim cust As New Customer With {
                                           .Name = "Blue Yonder Airlines",
                                           .CustomerID = 25374,
                                           .City = "Louisville",
                                           .State = "Kentucky"
                                      }
        cust.Name.PrintIndented()
        eol.PrintIndented()

        ' 算术表达式
        Dim answer =
            3 +
            8 -
            6 +
            12 *
            2

        CStr(answer).PrintIndented()
        eol.PrintIndented()

    End Sub

    ' 不再需要行继续符的特性。
    <Extension()>
    Sub PrintIndented(ByVal s As String)
        Form1.ResultsTextBox.Text &= "  " & s
    End Sub

End Module
