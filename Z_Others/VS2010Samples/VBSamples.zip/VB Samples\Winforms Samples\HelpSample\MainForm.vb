﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
Public Class MainForm


    Private Sub txtNumberValue_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtNumberValue.Validating
        If Not IsNumeric(txtNumberValue.Text) Then
            ' 激活错误提供程序以通知用户出现了
            ' 问题。
            ErrorProvider1.SetError(txtNumberValue, "Not a numeric value.")
        Else
            ' 清除错误
            ErrorProvider1.SetError(txtNumberValue, "")
        End If
    End Sub


    Private Sub exitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub contentsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles contentsToolStripMenuItem.Click
        ' 显示帮助文件的内容。
        Help.ShowHelp(Me, hpAdvancedCHM.HelpNamespace)
    End Sub

    Private Sub indexToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles indexToolStripMenuItem.Click
        ' 显示帮助文件的索引。
        Help.ShowHelpIndex(Me, hpAdvancedCHM.HelpNamespace)
    End Sub

    Private Sub searchToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles searchToolStripMenuItem.Click
        ' 显示帮助文件的搜索选项卡。
        Help.ShowHelp(Me, hpAdvancedCHM.HelpNamespace, HelpNavigator.Find, "")
    End Sub

    Private Sub ExitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

End Class