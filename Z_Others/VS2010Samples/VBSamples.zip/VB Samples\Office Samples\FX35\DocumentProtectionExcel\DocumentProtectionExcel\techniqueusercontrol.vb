﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。

Imports System.Globalization
Public Class TechniqueUserControl

    ''' <summary>
    ''' 将 dataDataGridView 绑定到数据源。
    ''' </summary>
    Private Sub TechniqueUserControl_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            dataDataGridView.DataSource = Globals.ThisWorkbook.custBindingSource
        Catch ex As Exception
            MessageBox.Show(ex.Message, _
                      "Error setting DataSource for dataDataGridView control.", _
                      MessageBoxButtons.OK, _
                      MessageBoxIcon.Error, _
                      MessageBoxDefaultButton.Button1)
        End Try

    End Sub

    ''' <summary>
    ''' 将值写入 dateDateTimePicker 控件，通过将只读
    ''' dateTextBox 的 ReadOnly 属性更改为 False 将值写入其中，然后设置
    ''' Text 属性并重新还原属性值。
    ''' </summary>
    ''' <param name="sender">未使用。</param>
    ''' <param name="e">未使用。</param>
    ''' <remarks></remarks>
    Private Sub dateDateTimePicker_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dateDateTimePicker.ValueChanged
        Try
            ' 将 dateDateTimePicker 值写入 dateNamedRange 
            Globals.Sheet1.dateNamedRange.Value2 = dateDateTimePicker.Value
            Try
                ' 取消保护 Sheet1 的 TextBox 值。
                Globals.Sheet1.dateTextBox.ReadOnly = False
                ' 以 ShortDatePattern 形式将 dateDateTimePicker 值写入 dateTextBox。
                Globals.Sheet1.dateTextBox.Text = dateDateTimePicker.Value.ToString("d", DateTimeFormatInfo.CurrentInfo)
            Finally
                ' 保护 Sheet1 的 TextBox 值。
                Globals.Sheet1.dateTextBox.ReadOnly = True
            End Try
        Catch ex As Exception
            MessageBox.Show(ex.Message, _
                       "Error changing dateNamedRange and dateTextBox value.", _
                       MessageBoxButtons.OK, _
                       MessageBoxIcon.Error, _
                       MessageBoxDefaultButton.Button1)
        End Try

    End Sub

End Class
