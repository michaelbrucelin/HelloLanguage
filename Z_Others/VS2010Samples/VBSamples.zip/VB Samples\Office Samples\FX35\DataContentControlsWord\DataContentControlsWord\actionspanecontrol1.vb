﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。

Public Class ActionsPaneControl1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Globals.ThisDocument.EmployeesBindingSource.MovePrevious()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Globals.ThisDocument.EmployeesBindingSource.MoveNext()

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim foundIndex As Integer
        Dim currentIndex As Integer

        currentIndex = Globals.ThisDocument.EmployeesBindingSource.Position

        foundIndex = Globals.ThisDocument.EmployeesBindingSource.Find("EmployeeID", TextBox1.Text)
        If (foundIndex < 0) Then
            '由于未能找到所输入的值，因此提示用户输入有效的 ID
            MessageBox.Show("Please enter a valid ID!")
            Globals.ThisDocument.EmployeesBindingSource.Position = currentIndex
        Else
            '移动到所找到的记录
            Globals.ThisDocument.EmployeesBindingSource.Position = foundIndex
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Globals.ThisDocument.PlainTextContentControl4.DataBindings("Text").WriteValue()
        Globals.ThisDocument.EmployeesBindingSource.EndEdit()
        Globals.ThisDocument.EmployeesTableAdapter.Update(Globals.ThisDocument.NorthwindDataSet.Employees)
        MsgBox("Title Updated")

    End Sub
End Class
