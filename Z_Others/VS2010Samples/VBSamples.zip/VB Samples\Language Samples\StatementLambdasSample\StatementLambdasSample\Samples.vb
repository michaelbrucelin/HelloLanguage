﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
Option Strict On

Public Class Samples

    ' <Sample ID="SingleLineSub" Description="Single-Line Sub" MethodName="SingleLineSub" />
    Public Function SingleLineSub() As String
        Dim results As New IO.StringWriter()
        Console.SetOut(results)

        ' 单行 Sub lambda 表达式是返回 void 的 
        ' 表达式，适用于产生副作用的情况，
        ' 如 Console.WriteLine 或 MsgBox。

        ' 在此示例中，单行 Sub 为
        ' 为 Array.ForEach 提供 Action 参数。Sub lambda 表达式
        ' 显示数组的每个元素。

        ' 不需要参数。

        Dim numbers = {3, 5, 19, 0, 34, 2}
        Console.Write("Results displayed by Array.ForEach: ")

        Array.ForEach(numbers, Sub(num) Console.Write(num & " "))

        Return results.ToString()
    End Function
    ' <EndSample ID="SingleLineSub" />

    ' <Sample ID="SingleLineFunction" Description="Single-Line Function" MethodName="SingleLineFunction" />
    Public Function SingleLineFunction(ByVal p1 As Object) As String
        Dim value As Integer
        If Not Integer.TryParse(p1.ToString(), value) Then _
            Return "Parameter value must be an integer."
        Dim results As New IO.StringWriter()
        Console.SetOut(results)

        ' 单行函数 lambda 表达式的主体是
        ' 单个表达式。注意，函数没有 As 子句。
        ' 函数的返回类型根据
        ' 表达式的返回类型推断。Labeler 的返回类型
        ' 为 String。

        ' 为参数 1 输入一个整数，则对于大于等于 0 的值，Labeler
        ' 返回“positive”；否则返回“negative”。

        Dim Labeler = Function(n As Integer) If(n >= 0, "positive",
            "negative")

        ' 函数 lambda 表达式可以与语言集成查询(LINQ)
        ' 中的标准查询运算符一同使用。
        ' 以下查询选择来自华盛顿州的客户。
        ' lambda 表达式的返回类型是
        ' Boolean。

        Dim customers = Customer.GetCustomerList()
        Dim WACusts = customers.Where(Function(cust) cust.State =
            "Washington")

        ' 执行查询并显示结果。
        Console.WriteLine()
        For Each cust In WACusts
            Console.WriteLine(cust.Name)
        Next

        Return "Labeler(" & p1.ToString & ") = " & Labeler(value) &
            vbCrLf & vbCrLf & "Customers in Washington: " &
            results.ToString()
    End Function
    ' <EndSample ID="SingleLineFunction" />

    ' <Sample ID="MultiLineSub" Description="Multiline Sub" MethodName="MultiLineSub" />
    Public Function MultiLineSub() As String
        Dim results As New IO.StringWriter()
        Console.SetOut(results)

        ' 多行 Sub lambda 表达式的主体比
        ' 单行表达式的限制要低，可以有效地使用 ByRef 
        ' 参数。在下面的
        ' 示例中，参数 intArray 中的每个元素都递增
        ' 1。

        ' 不需要参数。

        Dim numbers = {13, 0, 34, 71, 2}
        Dim Increment = Sub(ByRef intArray() As Integer)
                            For i = 0 To intArray.Length - 1
                                intArray(i) += 1
                            Next
                        End Sub

        Increment(numbers)

        Console.Write("Array elements after Increment: ")
        For Each num In numbers
            Console.Write(num & " ")
        Next

        Return results.ToString()
    End Function
    ' <EndSample ID="MultiLineSub" />

    ' <Sample ID="MultiLineFunction" Description="Multiline Function" MethodName="MultiLineFunction" />
    Public Function MultiLineFunction(ByVal p1 As Object) As String
        Dim value As Integer
        If Not Integer.TryParse(p1.ToString(), value) Then _
            Return "Parameter value must be an integer."

        ' 在此示例中使用了一个多行 lambda 表达式使您可以
        ' 调用 Randomize 方法，然后计算并
        ' 返回随机整数。指定函数返回类型的 As 语句
        ' 在此处是可选的，因为类型可以从
        ' 主体推断。

        ' 为参数 1 输入一个正整数，Randomizer
        ' 将返回一个介于 1 与参数值之间的随机
        ' 整数。

        Dim Randomizer = Function(max As Integer)
                             Randomize()
                             Return CInt(Int(max * Rnd() + 1))
                         End Function

        Return "Randomizer(" & value & ") = " & Randomizer(value)
    End Function
    ' <EndSample ID="MultiLineFunction" />


    ' <Sample ID="MultiLineFunctionWithAsClause" Description="Multiline Function with As Clause" MethodName="MultiLineFunctionWithAsClause" />
    Public Function MultiLineFunctionWithAsClause(ByVal p1 As Object,
                                                  ByVal p2 As Object)As String
        Dim value1 As Integer
        If Not Integer.TryParse(p1.ToString(), value1) Then _
            Return "Parameter 1 value must be an integer."
        Dim value2 As Integer
        If Not Integer.TryParse(p2.ToString(), value2) Then _
            Return "Parameter 2 value must be an integer."
        Dim results As New IO.StringWriter()
        Console.SetOut(results)

        ' 以下示例演示了一种情况，其中
        ' 可以使用 as 子句更改多行函数 lambda 表达式的 
        ' 的返回类型，而不是依赖编译器
        ' 推断类型

        ' 为参数 1 和参数 2 输入整数。

        Dim Greater = Function(n As Integer, p As Single) As Double
                          If n > p Then
                              Console.WriteLine(n &
                                  " is greater than or equal to " & p)
                              Return n
                          Else
                              Console.WriteLine(p &
                                  " is greater than or equal to " & n)
                              Return p
                          End If
                      End Function

        Console.Write("Greater(" & value1 & ", " & value2 & ") = ")
        Console.WriteLine(Greater(value1, value2))

        Return results.ToString()
    End Function
    ' <EndSample ID="MultiLineFunctionWithAsClause" />
    Function Announce(ByVal bigger As Integer, ByVal smaller As Integer) As String
        Return bigger & " is greater than or equal to " & smaller

    End Function

    ' <Sample ID="AssignFunctionToAction" Description="Assign Function to Action" MethodName="AssignFunctionToAction" />
    Public Function AssignFunctionToAction() As String
        Dim results As New IO.StringWriter()
        Console.SetOut(results)

        ' 宽松委托转换允许在需要 Sub lambda 表达式的时候使用 
        ' 函数 lambda 表达式。在下面
        ' 加倍数组中的每个元素并显示出来的示例中，
        ' 函数 lambda 表达式为 
        ' Action 参数传入。返回值将被忽略。

        ' 不需要参数。

        Dim numbers = {5, 19, 0, 34}
        Console.Write("Doubled values from Array.ForEach: ")
        Array.ForEach(numbers, Function(num)
                                   Dim times2 = num * 2
                                   Console.Write(times2 & " ")
                                   Return times2
                               End Function)

        Return results.ToString()
    End Function
    ' <EndSample ID="AssignFunctionToAction" />


    ' <Sample ID="RecursiveLambda" Description="Recursive Function" MethodName="RecursiveLambda" />
    Public Function RecursiveLambda(ByVal p1 As Object) As String
        Dim value As Integer
        If Not Integer.TryParse(p1.ToString(), value) Then _
            Return "Parameter value must be an integer."

        ' 若要编写递归函数 lambda 表达式，您必须
        ' 使用 Func 委托，如下面的示例所示。

        ' 为参数 1 输入一个 0 到 12 之间的正整数。

        Dim Factorial As Func(Of Integer, Integer) =
            Function(n)
                Return If(n = 0, 1, n * Factorial(n - 1))
            End Function

        Return "Factorial(" & p1.ToString() & ") = " &
            Factorial(value)
    End Function
    ' <EndSample ID="RecursiveLambda" />
End Class
