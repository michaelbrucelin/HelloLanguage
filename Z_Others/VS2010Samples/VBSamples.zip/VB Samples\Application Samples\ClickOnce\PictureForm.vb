﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。
Public Class PictureForm

    Private Sub PictureForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.MediaPictureBox.Image = System.Drawing.Image.FromFile("Winter.jpg")
    End Sub
End Class