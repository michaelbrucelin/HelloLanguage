﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。


Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Drawing
Imports System.Data
Imports System.Text
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports UiManagerOutlookAddIn.AddinUtilities


<ComVisible(True)> _
<ProgId("UiManager.SimpleControl")> _
<Guid("E2F1F0E8-254A-4ddc-A500-273D6EFB172B")> _
Partial Public Class SimpleControl
    Inherits UserControl

    Public Sub New()
        InitializeComponent()
    End Sub

    Private _mailServiceGroup As String = "mailServiceGroup"

    Private Sub closeCoffeeList_Click(ByVal sender As Object, ByVal e As EventArgs) _
     Handles _closeCoffeeList.Click
        ' 清除并隐藏列表框。
        Me._coffeeList.Items.Clear()
        Me._coffeeGroup.Visible = False

        ' 使外接程序服务功能区按钮再次不可见。
        Dim uiContainer As UserInterfaceContainer
        uiContainer = _
            Globals.ThisAddIn._uiElements.GetUIContainerForUserControl(Me)
        uiContainer.HideRibbonControl(_mailServiceGroup)
    End Sub

End Class


