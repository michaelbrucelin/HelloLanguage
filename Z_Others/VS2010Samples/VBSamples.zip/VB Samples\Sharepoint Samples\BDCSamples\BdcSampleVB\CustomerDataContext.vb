﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。
Option Strict On
Option Explicit On

Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Data.Linq
Imports System.Data.Linq.Mapping
Imports System.Linq
Imports System.Linq.Expressions
Imports System.Reflection

Partial Public Class CustomerDataContext
    Public Sub New()
        MyBase.New(Global.BdcSampleVB.Settings.Default.NORTHWNDConnectionString, mappingSource)
        OnCreated()
    End Sub
End Class
