﻿' 版权所有(C) Microsoft Corporation。保留所有权利。
' 此代码的发布遵从
' Microsoft 公共许可(MS-PL，http://opensource.org/licenses/ms-pl.html)的条款。



Imports Microsoft.VisualBasic
Imports System
Imports System.Diagnostics
Imports System.Windows.Input

Namespace EmployeeTracker.ViewModel.Helpers

    ''' <summary>
    ''' 基于委托的 ICommand 实现
    ''' </summary>
    Public Class DelegateCommand
        Implements ICommand
        ''' <summary>
        ''' 执行此命令时要执行的操作
        ''' </summary>
        Private executionAction As Action(Of Object)

        ''' <summary>
        ''' 用于确定该命令是否可有效执行的谓词
        ''' </summary>
        Private canExecutePredicate As Predicate(Of Object)

        ''' <summary>
        ''' 初始化 DelegateCommand 类的新实例。
        ''' 该命令将始终可以有效执行。
        ''' </summary>
        ''' <param name="execute">执行时要调用的委托</param>
        Public Sub New(ByVal execute As Action(Of Object))
            Me.New(execute, Nothing)
        End Sub

        ''' <summary>
        ''' 初始化 DelegateCommand 类的新实例。
        ''' </summary>
        ''' <param name="execute">执行时要调用的委托</param>
        ''' <param name="canExecute">用于确定该命令是否可有效执行的谓词</param>
        Public Sub New(ByVal execute As Action(Of Object), ByVal canExecute As Predicate(Of Object))
            If execute Is Nothing Then
                Throw New ArgumentNullException("execute")
            End If

            Me.executionAction = execute
            Me.canExecutePredicate = canExecute
        End Sub

        ''' <summary>
        ''' CanExecute 更改时引发
        ''' </summary>
        Public Custom Event CanExecuteChanged As EventHandler Implements ICommand.CanExecuteChanged
            AddHandler(ByVal value As EventHandler)
                AddHandler CommandManager.RequerySuggested, value
            End AddHandler
            RemoveHandler(ByVal value As EventHandler)
                RemoveHandler CommandManager.RequerySuggested, value
            End RemoveHandler
            RaiseEvent(ByVal sender As System.Object, ByVal e As System.EventArgs)
            End RaiseEvent
        End Event

        ''' <summary>
        ''' 执行支持此 DelegateCommand 的委托
        ''' </summary>
        ''' <param name="parameter">要传递给谓词的参数</param>
        ''' <returns>如果命令可有效执行，则为 True</returns>
        Public Function CanExecute(ByVal parameter As Object) As Boolean Implements ICommand.CanExecute
            Return If(Me.canExecutePredicate Is Nothing, True, Me.canExecutePredicate(parameter))
        End Function

        ''' <summary>
        ''' 执行支持此 DelegateCommand 的委托
        ''' </summary>
        ''' <param name="parameter">要传递给委托的参数</param>
        ''' <exception cref="InvalidOperationException">在 CanExecute 返回 false 时引发</exception>
        Public Sub Execute(ByVal parameter As Object) Implements ICommand.Execute
            If Not Me.CanExecute(parameter) Then
                Throw New InvalidOperationException("The command is not valid for execution, check the CanExecute method before attempting to execute.")
            End If

            Me.executionAction(parameter)
        End Sub
    End Class
End Namespace
