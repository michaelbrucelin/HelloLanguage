﻿' 此代码和信息“按原样”提供，不提供任何形式的
' 明示或暗示担保，包括但不限于
' 适销性和/或适合特定目的
' 的暗示担保。
'
' 版权所有(C) Microsoft Corporation。保留所有权利。

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Runtime.CompilerServices
Imports System.Resources

<Assembly: AssemblyTitle("UiManagerOutlookAddIn.AddinUtilities")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft")> 
<Assembly: AssemblyProduct("UiManagerOutlookAddIn.AddinUtilities")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft 2007")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 
<Assembly: Guid("56b8c20e-6940-4456-8625-174f9aa56136")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 

<Assembly: ClsCompliant(True)> 

<Assembly: NeutralResourcesLanguage("en-us")> 

